﻿using Microsoft.EntityFrameworkCore;

namespace ShoppingApp.Api.Models
{
    public class Transaction
    {
        public int TransactionId { get; set; }

        public int BudgetId { get; set; }

        [Precision(18, 2)]
        public decimal Amount { get; set; }

        public DateTime TransactionDate { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public Budget Budget { get; set; } = null!;
    }
}
