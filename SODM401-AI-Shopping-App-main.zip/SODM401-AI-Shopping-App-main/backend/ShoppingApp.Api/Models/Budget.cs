﻿using Microsoft.EntityFrameworkCore;

namespace ShoppingApp.Api.Models
{
    public class Budget
    {
        public int BudgetId { get; set; }

        public int UserId { get; set; }

        [Precision(18, 2)]
        public decimal Amount { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public User User { get; set; } = null!;
    }
}
