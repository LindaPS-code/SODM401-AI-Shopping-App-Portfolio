﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ShoppingApp.Api.Migrations
{
    /// <inheritdoc />
    public partial class SeedSprint1Data : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "UserId", "CreatedAt", "Email", "FirstName", "LastName", "PasswordHash" },
                values: new object[,]
                {
                    { 1, new DateTime(2026, 8, 23, 8, 0, 0, 0, DateTimeKind.Utc), "sanele@student.ac.za", "Sanele", "Dlamini", "DEV_HASH_1" },
                    { 2, new DateTime(2026, 8, 23, 8, 10, 0, 0, DateTimeKind.Utc), "amahle@student.ac.za", "Amahle", "Mkhize", "DEV_HASH_2" },
                    { 3, new DateTime(2026, 8, 23, 8, 20, 0, 0, DateTimeKind.Utc), "thando@student.ac.za", "Thando", "Nkosi", "DEV_HASH_3" }
                });

            migrationBuilder.InsertData(
                table: "Budgets",
                columns: new[] { "BudgetId", "Amount", "CreatedAt", "EndDate", "StartDate", "UserId" },
                values: new object[,]
                {
                    { 1, 1500.00m, new DateTime(2026, 8, 23, 8, 5, 0, 0, DateTimeKind.Utc), new DateTime(2026, 8, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 8, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1 },
                    { 2, 2000.00m, new DateTime(2026, 8, 23, 8, 15, 0, 0, DateTimeKind.Utc), new DateTime(2026, 8, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 8, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 2 },
                    { 3, 1200.00m, new DateTime(2026, 8, 23, 8, 25, 0, 0, DateTimeKind.Utc), new DateTime(2026, 8, 31, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 8, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 3 }
                });

            migrationBuilder.InsertData(
                table: "Transactions",
                columns: new[] { "TransactionId", "Amount", "BudgetId", "CreatedAt", "TransactionDate" },
                values: new object[,]
                {
                    { 1, 200.00m, 1, new DateTime(2026, 8, 5, 10, 0, 0, 0, DateTimeKind.Utc), new DateTime(2026, 8, 5, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, 125.00m, 1, new DateTime(2026, 8, 10, 12, 0, 0, 0, DateTimeKind.Utc), new DateTime(2026, 8, 10, 0, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, 200.00m, 1, new DateTime(2026, 8, 15, 14, 0, 0, 0, DateTimeKind.Utc), new DateTime(2026, 8, 15, 0, 0, 0, 0, DateTimeKind.Unspecified) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Budgets",
                keyColumn: "BudgetId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Budgets",
                keyColumn: "BudgetId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Transactions",
                keyColumn: "TransactionId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Transactions",
                keyColumn: "TransactionId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Transactions",
                keyColumn: "TransactionId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Budgets",
                keyColumn: "BudgetId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 1);
        }
    }
}
