﻿using Microsoft.EntityFrameworkCore;
using ShoppingApp.Api.Models;

namespace ShoppingApp.Api.Data
{
    public class ShoppingAppDbContext : DbContext
    {
        public ShoppingAppDbContext(DbContextOptions<ShoppingAppDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Budget> Budgets { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserId = 1,
                    FirstName = "Sanele",
                    LastName = "Dlamini",
                    Email = "sanele@student.ac.za",
                    PasswordHash = "DEV_HASH_1",
                    CreatedAt = new DateTime(2026, 8, 23, 8, 0, 0, DateTimeKind.Utc)
                },
                new User
                {
                    UserId = 2,
                    FirstName = "Amahle",
                    LastName = "Mkhize",
                    Email = "amahle@student.ac.za",
                    PasswordHash = "DEV_HASH_2",
                    CreatedAt = new DateTime(2026, 8, 23, 8, 10, 0, DateTimeKind.Utc)
                },
                new User
                {
                    UserId = 3,
                    FirstName = "Thando",
                    LastName = "Nkosi",
                    Email = "thando@student.ac.za",
                    PasswordHash = "DEV_HASH_3",
                    CreatedAt = new DateTime(2026, 8, 23, 8, 20, 0, DateTimeKind.Utc)
                }
            );

            modelBuilder.Entity<Budget>().HasData(
                new Budget
                {
                    BudgetId = 1,
                    UserId = 1,
                    Amount = 1500.00m,
                    StartDate = new DateTime(2026, 8, 1),
                    EndDate = new DateTime(2026, 8, 31),
                    CreatedAt = new DateTime(2026, 8, 23, 8, 5, 0, DateTimeKind.Utc)
                },
                new Budget
                {
                    BudgetId = 2,
                    UserId = 2,
                    Amount = 2000.00m,
                    StartDate = new DateTime(2026, 8, 1),
                    EndDate = new DateTime(2026, 8, 31),
                    CreatedAt = new DateTime(2026, 8, 23, 8, 15, 0, DateTimeKind.Utc)
                },
                new Budget
                {
                    BudgetId = 3,
                    UserId = 3,
                    Amount = 1200.00m,
                    StartDate = new DateTime(2026, 8, 1),
                    EndDate = new DateTime(2026, 8, 31),
                    CreatedAt = new DateTime(2026, 8, 23, 8, 25, 0, DateTimeKind.Utc)
                }
            );

            modelBuilder.Entity<Transaction>().HasData(
                new Transaction
                {
                    TransactionId = 1,
                    BudgetId = 1,
                    Amount = 200.00m,
                    TransactionDate = new DateTime(2026, 8, 5),
                    CreatedAt = new DateTime(2026, 8, 5, 10, 0, 0, DateTimeKind.Utc)
                },
                new Transaction
                {
                    TransactionId = 2,
                    BudgetId = 1,
                    Amount = 125.00m,
                    TransactionDate = new DateTime(2026, 8, 10),
                    CreatedAt = new DateTime(2026, 8, 10, 12, 0, 0, DateTimeKind.Utc)
                },
                new Transaction
                {
                    TransactionId = 3,
                    BudgetId = 1,
                    Amount = 200.00m,
                    TransactionDate = new DateTime(2026, 8, 15),
                    CreatedAt = new DateTime(2026, 8, 15, 14, 0, 0, DateTimeKind.Utc)
                }
            );
        }
    }
}
