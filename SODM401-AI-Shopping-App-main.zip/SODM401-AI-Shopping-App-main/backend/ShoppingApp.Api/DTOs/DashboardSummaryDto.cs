﻿namespace ShoppingApp.Api.DTOs
{
    public class DashboardSummaryDto
    {
        public string FirstName { get; set; } = string.Empty;

        public decimal Budget { get; set; }

        public decimal Spent { get; set; }

        public decimal Remaining { get; set; }

        public decimal RemainingPercentage { get; set; }

        public DateTime BudgetStartDate { get; set; }
        public DateTime BudgetEndDate { get; set; }
    }
}
