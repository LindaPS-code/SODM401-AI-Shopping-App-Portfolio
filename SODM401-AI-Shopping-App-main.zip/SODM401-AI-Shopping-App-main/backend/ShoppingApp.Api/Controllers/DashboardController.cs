﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShoppingApp.Api.Data;
using ShoppingApp.Api.DTOs;

namespace ShoppingApp.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly ShoppingAppDbContext _context;

        public DashboardController(ShoppingAppDbContext context)
        {
            _context = context;
        }

        [HttpGet("{userId}")]
        public async Task<ActionResult<DashboardSummaryDto>> GetDashboardSummary(int userId)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
            {
                return NotFound("User not found.");
            }

            var budget = await _context.Budgets
                .Where(b => b.UserId == userId)
                .OrderByDescending(b => b.StartDate)
                .FirstOrDefaultAsync();

            if (budget == null)
            {
                return NotFound("Budget not found.");
            }

            var spent = await _context.Transactions
                .Where(t => t.BudgetId == budget.BudgetId)
                .SumAsync(t => (decimal?)t.Amount) ?? 0m;

            var remaining = budget.Amount - spent;

            var remainingPercentage = budget.Amount > 0
                ? (remaining / budget.Amount) * 100
                : 0;

            var dashboardSummary = new DashboardSummaryDto
            {
                FirstName = user.FirstName,
                Budget = budget.Amount,
                Spent = spent,
                Remaining = remaining,
                RemainingPercentage = remainingPercentage,
                BudgetStartDate = budget.StartDate,
                BudgetEndDate = budget.EndDate
            };

            return Ok(dashboardSummary);
        }
    }
}
