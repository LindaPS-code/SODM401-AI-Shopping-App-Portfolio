using Microsoft.Extensions.Configuration;
using SmartShop.Api.Services;

static void Check(bool condition, string message)
{
    if (!condition) throw new Exception(message);
}

var store = new ExternalCodeStore();
var first = store.Create(42);
Check(store.Consume(first.Code, "another-browser") == null, "A handoff must be bound to its browser.");
var second = store.Create(42);
Check(store.Consume(second.Code, second.BrowserSecret) == 42, "A valid handoff should resolve the user.");
Check(store.Consume(second.Code, second.BrowserSecret) == null, "A handoff must not be replayed.");
Check(store.Consume("unknown", "unknown") == null, "Unknown handoffs must fail.");
var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>
{
    ["Authentication:Google:ClientId"] = "test-client",
    ["Authentication:Google:ClientSecret"] = "test-secret",
    ["Authentication:Apple:ClientId"] = "incomplete-client"
}).Build();
Check(ExternalAuthSetup.IsConfigured(config, "Google"), "A configured Google provider should be enabled.");
Check(!ExternalAuthSetup.IsConfigured(config, "Apple"), "A provider without its secret must not be enabled.");
Check(!ExternalAuthSetup.IsConfigured(config, "unknown"), "Unknown providers must not be enabled.");
Console.WriteLine("PASS: browser-bound handoff, replay prevention, unknown-code rejection, provider configuration checks.");

var sneakers = DemoCatalog.Search("sneakers", null, null, null, null, null, null);
Check(DemoCatalog.All.Count >= 70, "The catalogue should have a broad selection.");
Check(sneakers.Count >= 7, "Sneaker searches should include tagged shoe products.");
Check(DemoCatalog.Search("SHOES!", null, null, null, null, null, null).Count == sneakers.Count, "Search aliases and punctuation should agree.");
Check(DemoCatalog.Search("backpacks", null, null, null, null, null, null).Count >= 5, "Backpack selection is missing.");
Check(DemoCatalog.Search("headphones", null, null, null, null, null, null).Count >= 4, "Headphone selection is missing.");
foreach (var category in new[] { "Electronics", "Fashion", "Home", "Beauty", "Books" })
    Check(DemoCatalog.Search(null, null, null, null, null, null, null, category).Count >= 5, "Category is too narrow: " + category);
Check(DemoCatalog.Search("white sneakers", null, null, null, null, "White", null).Count > 0, "Combined terms and metadata filters should match.");
Check(DemoCatalog.Search("unobtainium", null, null, null, null, null, null).Count == 0, "Unknown searches should not return unrelated products.");
Check(DemoCatalog.Search("sneakers", null, 1, null, null, null, null).Count == 0, "Price filters must be applied.");
Check(DemoCatalog.All.All(product => product.ImageUrl?.StartsWith("/products/") == true), "All sample images must be bundled.");
Console.WriteLine($"PASS: {DemoCatalog.All.Count} offers, {sneakers.Count} sneaker results, category coverage, aliases and combined filters.");

Check(DemoCatalog.All.All(p => p.ProductUrl?.StartsWith("https://") == true), "Every retailer product requires an exact link.");
Check(DemoCatalog.Search("sneakers", null, null, null, null, null, "8").Count == 0, "Unknown size availability must not be invented.");
