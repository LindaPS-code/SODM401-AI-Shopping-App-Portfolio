const BASE_URL = import.meta.env.VITE_API_BASE_URL || ''

export function getToken() {
  return localStorage.getItem('smartshop_token')
}

export async function apiFetch(path, options = {}) {
  const token = getToken()
  const headers = new Headers(options.headers)
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json')
  }
  if (token) {
    headers.set('Authorization', `Bearer ${token}`)
  }

  const response = await fetch(`${BASE_URL}${path}`, { ...options, headers })
  const text = await response.text()
  let data = null
  try { data = text ? JSON.parse(text) : null } catch { /* Servers may return plain-text errors. */ }

  if (!response.ok) {
    if (response.status === 401 && !path.startsWith('/api/auth/')) {
      localStorage.removeItem('smartshop_token')
      localStorage.removeItem('smartshop_user')
      window.dispatchEvent(new Event('smartshop-session'))
    }
    const message = data?.message || data?.title || `Request failed (${response.status})`
    const error = new Error(message)
    error.status = response.status
    throw error
  }

  return data
}

export const orderApi = {
  checkout: (body) =>
    apiFetch('/api/orders/checkout', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
}
