import { apiFetch } from './api'

export function searchProducts(filters) {
  const params = new URLSearchParams()
  const shippingMap = { Free: 'free', 'Under R50': 'under50', 'Under R100': 'under100' }
  for (const [key, value] of Object.entries(filters)) {
    if (value === '' || value == null || value === 'Any') continue
    params.set(key === 'query' ? 'q' : key === 'colour' ? 'color' : key, key === 'shipping' ? shippingMap[value] || value : value)
  }
  return apiFetch(`/api/products/search?${params}`)
}
