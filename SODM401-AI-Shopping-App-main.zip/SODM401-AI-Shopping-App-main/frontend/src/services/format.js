export const money = value => new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR' }).format(value || 0)
export const productPath = product => `/products/${encodeURIComponent(product.externalId)}`
