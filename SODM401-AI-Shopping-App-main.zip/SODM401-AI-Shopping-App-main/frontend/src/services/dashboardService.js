import { apiFetch } from './api'

export async function getDashboardSummary() {
  const budget = await apiFetch('/api/budgets/current')
  return { budget: budget.amount, spent: budget.spentAmount, remaining: budget.remainingAmount, remainingPercentage: budget.percentRemaining }
}
