import { useEffect, useState } from 'react'
import { apiFetch } from '../services/api'

export default function useApi(path) {
  const [state, setState] = useState({ data: null, error: '', loading: true })
  const [version, setVersion] = useState(0)
  useEffect(() => {
    const controller = new AbortController()
    apiFetch(path, { signal: controller.signal }).then(data => {
      if (!controller.signal.aborted) setState({ data, error: '', loading: false, path })
    }).catch(error => {
      if (!controller.signal.aborted) setState({ data: null, error: error.message, loading: false, path })
    })
    return () => controller.abort()
  }, [path, version])
  return { ...(state.path === path ? state : { data: null, error: '', loading: true }), reload: () => setVersion(value => value + 1) }
}
