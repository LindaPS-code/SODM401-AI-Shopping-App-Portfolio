import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { apiFetch, getToken } from '../services/api'

const AuthContext = createContext(null)
function readUser() {
  try { return getToken() ? JSON.parse(localStorage.getItem('smartshop_user')) : null } catch { return null }
}
export function AuthProvider({ children }) {
  const [user, setUser] = useState(readUser)
  useEffect(() => {
    const sync = () => setUser(readUser())
    window.addEventListener('smartshop-session', sync)
    window.addEventListener('storage', sync)
    return () => { window.removeEventListener('smartshop-session', sync); window.removeEventListener('storage', sync) }
  }, [])
  const acceptSession = useCallback((result) => {
    const { token, ...profile } = result
    localStorage.setItem('smartshop_token', token)
    localStorage.setItem('smartshop_user', JSON.stringify(profile))
    setUser(profile)
  }, [])
  async function authenticate(mode, body) {
    const result = await apiFetch(`/api/auth/${mode}`, { method: 'POST', body: JSON.stringify(body) })
    acceptSession(result)
  }
  function logout() {
    localStorage.removeItem('smartshop_token')
    localStorage.removeItem('smartshop_user')
    setUser(null)
  }
  return <AuthContext.Provider value={{ user, authenticate, acceptSession, logout }}>{children}</AuthContext.Provider>
}
// Context hooks share their provider module intentionally.
// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() { return useContext(AuthContext) }
