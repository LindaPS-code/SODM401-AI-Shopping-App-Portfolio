import { createContext, useContext, useState, useEffect } from 'react'

const AddressContext = createContext(null)
function storageKey() { return 'smartshop_address_' + (JSON.parse(localStorage.getItem('smartshop_user') || '{}').userId || 'guest') }

function readAddress() {
  try {
    const raw = localStorage.getItem(storageKey())
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export function AddressProvider({ children }) {
  const [address, setAddressState] = useState(readAddress)

  useEffect(() => {
    if (address) {
      localStorage.setItem(storageKey(), JSON.stringify(address))
    } else {
      localStorage.removeItem(storageKey())
    }
  }, [address])

  function setAddress(newAddress) {
    setAddressState(newAddress)
  }

  return (
    <AddressContext.Provider value={{ address, setAddress }}>
      {children}
    </AddressContext.Provider>
  )
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAddress() {
  const context = useContext(AddressContext)
  if (!context) throw new Error('useAddress must be used inside AddressProvider')
  return context
}
