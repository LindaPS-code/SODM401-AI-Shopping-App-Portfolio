import { createContext, useContext, useState, useEffect } from 'react'

const PaymentContext = createContext(null)
function storageKey() { return 'smartshop_card_' + (JSON.parse(localStorage.getItem('smartshop_user') || '{}').userId || 'guest') }

function readCard() {
  try {
    const raw = localStorage.getItem(storageKey())
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

export function PaymentProvider({ children }) {
  const [card, setCardState] = useState(readCard)

  useEffect(() => {
    if (card) {
      localStorage.setItem(storageKey(), JSON.stringify(card))
    } else {
      localStorage.removeItem(storageKey())
    }
  }, [card])

  function setCard(newCard) {
    setCardState(newCard)
  }

  return (
    <PaymentContext.Provider value={{ card, setCard }}>
      {children}
    </PaymentContext.Provider>
  )
}

// eslint-disable-next-line react-refresh/only-export-components
export function usePayment() {
  const context = useContext(PaymentContext)
  if (!context) throw new Error('usePayment must be used inside PaymentProvider')
  return context
}
