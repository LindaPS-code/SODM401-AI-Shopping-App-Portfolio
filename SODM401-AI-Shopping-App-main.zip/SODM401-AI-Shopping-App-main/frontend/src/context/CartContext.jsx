import { createContext, useContext, useState, useEffect } from 'react'

const CartContext = createContext(null)
function storageKey() { return 'smartshop_cart_' + (JSON.parse(localStorage.getItem('smartshop_user') || '{}').userId || 'guest') }

function readCart() {
  try {
    const raw = localStorage.getItem(storageKey())
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(readCart)

  useEffect(() => {
    localStorage.setItem(storageKey(), JSON.stringify(items))
  }, [items])

  function addToCart(product, quantity = 1) {
    setItems((current) => {
      const existing = current.find((item) => item.externalId === product.externalId)
      if (existing) {
        return current.map((item) =>
          item.externalId === product.externalId
            ? { ...item, quantity: item.quantity + quantity }
            : item,
        )
      }
      return [...current, { ...product, quantity }]
    })
  }

  function updateQuantity(externalId, quantity) {
    setItems((current) =>
      current.map((item) => (item.externalId === externalId ? { ...item, quantity } : item)),
    )
  }

  function removeFromCart(externalId) {
    setItems((current) => current.filter((item) => item.externalId !== externalId))
  }

  function clearCart() {
    setItems([])
  }

  const value = { items, addToCart, updateQuantity, removeFromCart, clearCart }

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useCart() {
  const context = useContext(CartContext)
  if (!context) throw new Error('useCart must be used inside CartProvider')
  return context
}
