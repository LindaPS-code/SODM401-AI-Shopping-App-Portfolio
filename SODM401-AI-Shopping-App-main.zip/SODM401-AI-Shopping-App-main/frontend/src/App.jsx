import { BrowserRouter, Navigate, Outlet, Routes, Route, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { AuthProvider, useAuth } from './context/AuthContext'
import { CartProvider } from './context/CartContext'
import { AddressProvider } from './context/AddressContext'
import { PaymentProvider } from './context/PaymentContext'
import Splash from './pages/Splash'
import Login from './pages/Login'
import SignUp from './pages/SignUp'
import HomeDashboard from './pages/HomeDashboard'
import Checkout from './pages/checkout'
import Budget, { BudgetHistory } from './pages/Budget'
import Search from './pages/Search'
import FiltersPage from './pages/FiltersPage'
import ProductLists from './pages/ProductLists'
import ProductDetails from './pages/ProductDetails'
import BudgetAlert from './pages/BudgetAlert'
import OrderConfirmation from './pages/OrderConfirmation'
import Profile from './pages/Profile'
import ExternalCallback from './pages/ExternalCallback'
import './App.css'
import './Shop.css'

function Protected() {
  const { user } = useAuth()
  return user ? <CartProvider key={user.userId}><AddressProvider><PaymentProvider><Outlet /></PaymentProvider></AddressProvider></CartProvider> : <Navigate to="/login" replace />
}
function KeyedList({ mode }) {
  const location = useLocation()
  return <ProductLists key={`${mode}:${location.search}`} mode={mode} />
}
function ScrollReset() {
  const { pathname, search } = useLocation()
  useEffect(() => { window.scrollTo(0, 0) }, [pathname, search])
  return null
}
export default function App() {
  return <AuthProvider><BrowserRouter><ScrollReset /><Routes>
    <Route path="/" element={<Splash />} />
    <Route path="/login" element={<Login />} />
    <Route path="/signup" element={<SignUp />} />
    <Route path="/auth/callback" element={<ExternalCallback />} />
    <Route element={<Protected />}>
      <Route path="/dashboard" element={<HomeDashboard />} />
      <Route path="/budget" element={<Budget />} />
      <Route path="/budget/history" element={<BudgetHistory />} />
      <Route path="/search" element={<Search />} />
      <Route path="/results" element={<KeyedList mode="results" />} />
      <Route path="/filters" element={<FiltersPage />} />
      <Route path="/compare" element={<KeyedList mode="compare" />} />
      <Route path="/products/:id" element={<ProductDetails />} />
      <Route path="/recommendations" element={<KeyedList mode="recommendations" />} />
      <Route path="/favourites" element={<KeyedList mode="favourites" />} />
      <Route path="/budget-alert" element={<BudgetAlert />} />
      <Route path="/checkout" element={<Checkout />} />
      <Route path="/orders/:id" element={<OrderConfirmation />} />
      <Route path="/profile" element={<Profile />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes></BrowserRouter></AuthProvider>
}
