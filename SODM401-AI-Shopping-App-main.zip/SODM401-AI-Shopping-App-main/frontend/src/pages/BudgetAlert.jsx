import { Link, useLocation } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import { useCart } from '../context/CartContext'
import useApi from '../hooks/useApi'
import { money } from '../services/format'

export default function BudgetAlert() {
  const { state } = useLocation()
  const { items } = useCart()
  const { data, error, loading } = useApi('/api/budgets/current')
  const total = items.reduce((sum, item) => sum + (item.price + (item.shippingCost || 0)) * item.quantity, 0)
  const remaining = data?.remainingAmount ?? state?.alert?.remainingBudget ?? 0
  return <ShopLayout title="Budget Alert">{loading ? <p>Checking budget…</p> : error ? <p role="alert">{error}</p> : <><div className="budget-warning"><span>👛</span><h2>{total > remaining ? 'This purchase exceeds your available budget.' : 'Your purchase is now within budget.'}</h2></div><div className="shop-card"><p className="row"><span>Order total</span><strong>{money(total)}</strong></p><p>Your remaining budget: <strong className="green">{money(remaining)}</strong></p><p>Short by: <strong className="price">{money(Math.max(0, total - remaining))}</strong></p></div><h3>What can you do?</h3><Link className="shop-secondary" to="/recommendations">View similar items within budget ›</Link><Link className="shop-secondary" to="/budget">Increase your budget ›</Link><Link className="shop-secondary" to="/checkout">Review your cart ›</Link></>}</ShopLayout>
}
