import { Link, useParams } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import useApi from '../hooks/useApi'
import { money } from '../services/format'

export default function OrderConfirmation() {
  const { id } = useParams()
  const { data: order, error, loading } = useApi(`/api/orders/${id}`)
  return <ShopLayout title="Order Confirmation">{loading && <p>Loading order…</p>}{error && <p role="alert">{error}</p>}{order && <div className="confirmation"><div className="success-mark">✓</div><h2>Order Placed!</h2><p>Thank you for shopping smart.</p><p>Order Number</p><h3 className="green">#{order.orderNumber}</h3><p>{money(order.totalAmount)}</p><p className="muted">Your order has been saved in SmartShop. This project does not charge your card or place a retailer order.</p><Link className="shop-primary" to="/search">Continue Shopping</Link></div>}</ShopLayout>
}
