import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import './SignUp.css'
import { useAuth } from '../context/AuthContext'

function SignUp() {
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  const navigate = useNavigate()
  const { authenticate } = useAuth()
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  async function submit(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const names = form.get('name').trim().split(/\s+/)
    if (names.length < 2) { setError('Please enter your first and last name.'); return }
    if (form.get('password') !== form.get('confirm')) { setError('Passwords do not match.'); return }
    setBusy(true); setError('')
    try {
      await authenticate('register', { firstName: names.shift(), lastName: names.join(' '), email: form.get('email'), password: form.get('password') })
      navigate('/budget')
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <div className="signup-page">
      <div className="signup-content">

        <h1>Create Account</h1>

        <p className="signup-subtitle">
          Sign up to get started
        </p>

        <form className="signup-form" onSubmit={submit}>

          <label htmlFor="full-name">Full Name</label>

          <input
            id="full-name"
            name="name" required
            type="text"
            placeholder="Enter your full name"
          />

          <label htmlFor="signup-email">Email</label>

          <input
            id="signup-email"
            name="email" required
            type="email"
            placeholder="sanele@student.co.za"
          />

          <label htmlFor="signup-password">Password</label>

          <div className="signup-password-container">

            <input
              id="signup-password"
              name="password" required minLength={6}
              type={showPassword ? 'text' : 'password'}
              placeholder="Create a password"
            />

            <button
              type="button"
              className="signup-eye-button"
              onClick={() => setShowPassword(!showPassword)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? '🙈' : '👁️'}
            </button>

          </div>

          <label htmlFor="confirm-password">Confirm Password</label>

          <div className="signup-password-container">

            <input
              id="confirm-password"
              name="confirm" required minLength={6}
              type={showConfirmPassword ? 'text' : 'password'}
              placeholder="Confirm your password"
            />

            <button
              type="button"
              className="signup-eye-button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              aria-label={
                showConfirmPassword
                  ? 'Hide confirm password'
                  : 'Show confirm password'
              }
            >
              {showConfirmPassword ? '🙈' : '👁️'}
            </button>

          </div>

          <button
            type="submit"
            className="signup-button"
            disabled={busy}
          >
            {busy ? 'Creating account…' : 'Sign Up'}
          </button>

          {error && <p role="alert">{error}</p>}
        </form>

        <p className="already-account">
          Already have an account?{' '}
          <button
            type="button"
            className="login-link"
            onClick={() => navigate('/login')}
          >
            Log in
          </button>
        </p>

      </div>
    </div>
  )
}

export default SignUp
