import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import './Login.css'
import { useAuth } from '../context/AuthContext'
import { apiFetch } from '../services/api'
import useApi from '../hooks/useApi'

function Login() {
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const navigate = useNavigate()
  const { authenticate } = useAuth()
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const providers = useApi('/api/auth/external/providers')
  const [params] = useSearchParams()
  const externalError = {
    external_failed: 'Provider sign-in was cancelled or could not be verified. Please try again.',
    not_configured: 'This sign-in provider has not been activated yet. You can use email and password.',
    account_exists: 'An account already uses this email. Sign in with your original method; accounts are not linked automatically.',
  }[params.get('authError')]
  function socialSignIn(name) {
    const provider = providers.data?.find(item => item.name === name)
    if (!provider?.enabled) { setError(`${name} sign-in needs provider setup. Please use email and password for now.`); return }
    window.location.assign(`${import.meta.env.VITE_API_BASE_URL || ''}${provider.url}`)
  }
  async function submit(event) {
    event.preventDefault()
    setBusy(true); setError('')
    try {
      await authenticate('login', { email, password })
      try { await apiFetch('/api/budgets/current'); navigate('/dashboard') }
      catch (err) { if (err.status === 404) navigate('/budget'); else throw err }
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <div className="login-page">
      <div className="login-content">

        <h1>Welcome Back!</h1>

        <p className="login-subtitle">
          Log in to continue
        </p>

        <form className="form-section" onSubmit={submit}>

          <label htmlFor="email">Email</label>

          <input
            id="email"
            type="email"
            required
            placeholder="sanele@student.co.za"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <label htmlFor="password">Password</label>

          <div className="password-container">

            <input
              id="password"
              required
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <button
              type="button"
              className="eye-button"
              onClick={() => setShowPassword(!showPassword)}
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? '🙈' : '👁️'}
            </button>

          </div>

          <button
            type="button"
            className="forgot-password"
            onClick={() => setError('Password recovery is not configured. Please contact your project administrator.')}
          >
            Forgot password?
          </button>

          <button
            type="submit"
            className="login-button"
            disabled={busy}
          >
            {busy ? 'Logging in…' : 'Log In'}
          </button>

          {(error || externalError) && <p role="alert">{error || externalError}</p>}
        </form>

        <p className="continue-text">
          or continue with
        </p>

        <div className="social-buttons">

          <button
            type="button"
            className="social-button"
            onClick={() => socialSignIn('Google')}
            disabled={providers.loading || busy}
          >
            <span className="google-icon">G</span>
            Google
          </button>

          <button
            type="button"
            className="social-button"
            onClick={() => socialSignIn('Apple')}
            disabled={providers.loading || busy}
          >
            <span className="apple-icon"></span>
            Apple
          </button>

        </div>

        <p className="signup-text">
          Don't have an account?{' '}
          <button
            type="button"
            className="signup-link"
            onClick={() => navigate('/signup')}
          >
            Sign up
          </button>
        </p>

      </div>
    </div>
  )
}

export default Login
