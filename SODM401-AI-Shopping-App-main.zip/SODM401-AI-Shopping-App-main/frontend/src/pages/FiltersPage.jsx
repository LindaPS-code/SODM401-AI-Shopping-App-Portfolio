import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import "./FiltersPage.css";

const MAX_PRICE = 2500;

const sizes = ["6", "7", "8", "9", "10", "11"];

const colours = [
  { name: "White", value: "#ffffff" },
  { name: "Black", value: "#111111" },
  { name: "Grey", value: "#9ca3af" },
  { name: "Blue", value: "#2563eb" },
  { name: "Red", value: "#ef4444" },
  { name: "Pink", value: "#ec4899" },
];

const shippingOptions = ["Any", "Free", "Under R50", "Under R100"];

function FiltersPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [minPrice, setMinPrice] = useState(Number(params.get("minPrice") || 0));
  const [maxPrice, setMaxPrice] = useState(Number(params.get("maxPrice") || MAX_PRICE));

  const [selectedSize, setSelectedSize] = useState(params.get("size") || "");
  const [selectedColour, setSelectedColour] = useState(params.get("color") || "");

  const [shipping, setShipping] = useState(({free:"Free",under50:"Under R50",under100:"Under R100"})[params.get("shipping")] || "Any");
  const [location, setLocation] = useState(params.get("location") || "");

  const selectSize = (size) => {
    setSelectedSize((current) => (current === size ? "" : size));
  };

  const selectColour = (colour) => {
    setSelectedColour((current) => (current === colour ? "" : colour));
  };

  const clearFilters = () => {
    setMinPrice(0);
    setMaxPrice(MAX_PRICE);
    setSelectedSize("");
    setSelectedColour("");
    setShipping("Any");
    setLocation("");
  };

  const handleMinPriceChange = (event) => {
    const value = Number(event.target.value);

    if (Number.isNaN(value)) {
      return;
    }

    const safeValue = Math.max(0, Math.min(value, maxPrice, MAX_PRICE));

    setMinPrice(safeValue);
  };

  const handleMaxPriceChange = (event) => {
    const value = Number(event.target.value);

    if (Number.isNaN(value)) {
      return;
    }

    const safeValue = Math.max(minPrice, Math.min(value, MAX_PRICE));

    setMaxPrice(safeValue);
  };

  const handleMinSliderChange = (event) => {
    const value = Number(event.target.value);

    if (value <= maxPrice) {
      setMinPrice(value);
    }
  };

  const handleMaxSliderChange = (event) => {
    const value = Number(event.target.value);

    if (value >= minPrice) {
      setMaxPrice(value);
    }
  };

  const handleApplyFilters = () => {
    const next = new URLSearchParams(params);
    const filters = { minPrice, maxPrice: maxPrice === MAX_PRICE ? '' : maxPrice, size: selectedSize, color: selectedColour, shipping: ({Free:'free','Under R50':'under50','Under R100':'under100'})[shipping] || '', location };
    for (const [key, value] of Object.entries(filters)) {
      if (value === '') next.delete(key); else next.set(key, value);
    }
    navigate(`/results?${next}`);
  };

  const minPosition = (minPrice / MAX_PRICE) * 100;

  const maxPosition = (maxPrice / MAX_PRICE) * 100;

  return (
    <div className="filters-page">
      <main className="filters-card">
        <header className="filters-header">
          <div>
            <button className="clear-button" onClick={() => navigate(`/results?${params}`)}>‹ Back to results</button>

            <h1>Filters</h1>
          </div>

          <button type="button" className="clear-button" onClick={clearFilters}>
            Clear all
          </button>
        </header>

        {/* PRICE RANGE */}
        <section className="filter-section">
          <div className="section-heading">
            <h2>Price Range</h2>

            <span>
              R{minPrice.toLocaleString()} –{" "}
              {maxPrice >= MAX_PRICE
                ? "R2,500+"
                : `R${maxPrice.toLocaleString()}`}
            </span>
          </div>

          <div className="price-controls">
            <label>
              <span>Minimum</span>

              <div className="price-input">
                <span>R</span>

                <input
                  type="number"
                  min="0"
                  max={maxPrice}
                  step="50"
                  value={minPrice}
                  onChange={handleMinPriceChange}
                  aria-label="Minimum price"
                />
              </div>
            </label>

            <label>
              <span>Maximum</span>

              <div className="price-input">
                <span>R</span>

                <input
                  type="number"
                  min={minPrice}
                  max={MAX_PRICE}
                  step="50"
                  value={maxPrice}
                  onChange={handleMaxPriceChange}
                  aria-label="Maximum price"
                />
              </div>
            </label>
          </div>

          <div
            className="range-group"
            style={{
              "--min-position": `${minPosition}%`,
              "--max-position": `${maxPosition}%`,
            }}
          >
            <div className="slider-track" />

            <div className="slider-selected-range" />

            <input
              className="range-input range-min"
              type="range"
              min="0"
              max={MAX_PRICE}
              step="50"
              value={minPrice}
              onChange={handleMinSliderChange}
              aria-label="Minimum price slider"
            />

            <input
              className="range-input range-max"
              type="range"
              min="0"
              max={MAX_PRICE}
              step="50"
              value={maxPrice}
              onChange={handleMaxSliderChange}
              aria-label="Maximum price slider"
            />
          </div>

          <div className="range-labels">
            <span>R0</span>
            <span>R2,500+</span>
          </div>
        </section>

        {/* SIZE */}
        <section className="filter-section">
          <h2>Size</h2>

          <div className="size-options">
            {sizes.map((size) => (
              <button
                key={size}
                type="button"
                className={`option-button ${
                  selectedSize === size ? "selected" : ""
                }`}
                onClick={() => selectSize(size)}
              >
                {size}
              </button>
            ))}
          </div>
        </section>

        {/* COLOUR */}
        <section className="filter-section">
          <h2>Colour</h2>

          <div className="colour-options">
            {colours.map((colour) => {
              const selected = selectedColour === colour.name;

              return (
                <button
                  key={colour.name}
                  type="button"
                  className={`colour-button ${selected ? "selected" : ""}`}
                  onClick={() => selectColour(colour.name)}
                  aria-label={colour.name}
                  title={colour.name}
                >
                  <span
                    className="colour-swatch"
                    style={{
                      backgroundColor: colour.value,
                    }}
                  />
                </button>
              );
            })}


          </div>
        </section>

        {/* SHIPPING COST */}
        <section className="filter-section">
          <h2>Shipping Cost</h2>

          <div className="shipping-options">
            {shippingOptions.map((option) => (
              <button
                key={option}
                type="button"
                className={`shipping-button ${
                  shipping === option ? "selected" : ""
                }`}
                onClick={() => setShipping(option)}
              >
                {option}
              </button>
            ))}
          </div>
        </section>

        {/* LOCATION */}
        <section className="filter-section">
          <label className="location-label" htmlFor="location">
            Location
          </label>

          <select
            id="location"
            className="location-select"
            value={location}
            onChange={(event) => setLocation(event.target.value)}
          >
            <option value="">All locations</option><option value="Johannesburg">Johannesburg</option>

            <option value="Durban">Durban</option>

            <option value="Cape Town">Cape Town</option>

            <option value="Pretoria">Pretoria</option>

            <option value="Gqeberha">Gqeberha</option>
          </select>
        </section>

        {/* APPLY FILTERS */}
        <div className="filter-actions">
          <button
            type="button"
            className="apply-button"
            onClick={handleApplyFilters}
          >
            Apply Filters
          </button>
        </div>
      </main>
    </div>
  );
}

export default FiltersPage;

