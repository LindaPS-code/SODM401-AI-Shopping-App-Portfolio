import { Link } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import { useAuth } from '../context/AuthContext'
import useApi from '../hooks/useApi'
import { money } from '../services/format'

export default function Profile() {
  const { user, logout } = useAuth()
  const { data, error, loading } = useApi('/api/orders')
  return <ShopLayout title="Profile"><h2>{user.firstName} {user.lastName}</h2><p>{user.email}</p><button className="shop-secondary" onClick={logout}>Log out</button><h2>Your Orders</h2>{loading && <p>Loading orders…</p>}{error && <p role="alert">{error}</p>}{data?.length === 0 && <p>No orders yet.</p>}{data?.map(order => <Link className="shop-card row" key={order.orderId} to={`/orders/${order.orderId}`}><span>#{order.orderNumber}</span><strong>{money(order.totalAmount)}</strong></Link>)}</ShopLayout>
}
