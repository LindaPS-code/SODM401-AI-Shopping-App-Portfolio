import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import { apiFetch } from '../services/api'
import { money } from '../services/format'
import useApi from '../hooks/useApi'

export default function Budget() {
  const [amount, setAmount] = useState(1500)
  const [spent, setSpent] = useState(0)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const navigate = useNavigate()
  useEffect(() => {
    let active = true
    apiFetch('/api/budgets/current').then(data => { if (active) { setAmount(data.amount); setSpent(data.spentAmount) } })
      .catch(err => { if (active && err.status !== 404) setError(err.message) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [])
  async function save(event) {
    event.preventDefault(); setBusy(true); setError('')
    try { await apiFetch('/api/budgets/current', { method: 'PUT', body: JSON.stringify({ amount: Number(amount) }) }); navigate('/dashboard') }
    catch (err) { setError(err.message) } finally { setBusy(false) }
  }
  return <ShopLayout title="Set Your Monthly Budget"><p className="muted centered">Tell us your budget to get smarter recommendations.</p>{loading ? <p>Loading budget…</p> : <form onSubmit={save} className="budget-form"><label>Monthly budget<input type="number" min="1" max="1000000" step="0.01" required value={amount} onChange={e => setAmount(e.target.value)} /></label><h2 className="centered">{money(Number(amount))}</h2><input aria-label="Monthly budget slider" type="range" min="100" max={Math.max(10000, Number(amount))} step="100" value={amount} onChange={e => setAmount(e.target.value)} /><div className="shop-card"><h3>Your budget summary</h3><p className="row"><span>Budget</span><strong>{money(Number(amount))}</strong></p><p className="row"><span>Spent</span><span>{money(spent)}</span></p><p className="row"><span>Remaining</span><strong className="green">{money(Number(amount) - spent)}</strong></p></div><button className="shop-primary" disabled={busy}>{busy ? 'Saving…' : 'Save & Continue'}</button></form>}{error && <p role="alert">{error}</p>}<Link to="/budget/history">View budget history</Link></ShopLayout>
}

export function BudgetHistory() {
  const { data, error, loading } = useApi('/api/budgets')
  return <ShopLayout title="Budget History">{loading && <p>Loading…</p>}{error && <p role="alert">{error}</p>}{data?.length === 0 && <p>No budgets yet.</p>}{data?.map(b => <div className="shop-card" key={b.budgetId}><h3>{b.startDate} – {b.endDate}</h3><p>Budget: {money(b.amount)}</p><p>Spent: {money(b.spentAmount)}</p><p className="green">Remaining: {money(b.remainingAmount)}</p></div>)}<Link to="/budget">Set this month’s budget</Link></ShopLayout>
}
