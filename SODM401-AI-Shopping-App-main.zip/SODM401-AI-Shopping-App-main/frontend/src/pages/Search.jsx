import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import useApi from '../hooks/useApi'

export function SearchForm({ initial = '' }) {
  const [query, setQuery] = useState(initial)
  const navigate = useNavigate()
  return <form className="search-form" onSubmit={e => { e.preventDefault(); navigate(`/results?q=${encodeURIComponent(query.trim())}`) }}><input aria-label="Search products" placeholder="Search for products, brands…" value={query} onChange={e => setQuery(e.target.value)} required /><button className="shop-primary">Search</button></form>
}
export default function Search() {
  const popular = useApi('/api/products/popular-searches')
  const categories = useApi('/api/products/categories')
  return <ShopLayout title="Search Products"><SearchForm /><h2>Popular Searches</h2>{popular.error && <p role="alert">{popular.error}</p>}<div className="chips">{popular.data?.map(name => <Link key={name} to={`/results?q=${encodeURIComponent(name)}`}>{name}</Link>)}</div><h2>Browse Categories</h2>{categories.error && <p role="alert">{categories.error}</p>}<div className="category-grid">{categories.data?.map((category, i) => <Link key={category.name} to={`/results?category=${encodeURIComponent(category.name)}`}><span>{['🎧', '👕', '🏠', '🧴', '📚'][i]}</span>{category.name}</Link>)}</div></ShopLayout>
}
