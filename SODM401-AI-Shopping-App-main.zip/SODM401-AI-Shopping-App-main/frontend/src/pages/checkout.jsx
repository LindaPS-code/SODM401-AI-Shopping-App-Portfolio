import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { useAddress } from '../context/AddressContext'
import { usePayment } from '../context/PaymentContext'
import { orderApi } from '../services/api'
import AddressForm from '../components/AddressForm'
import CardForm from '../components/CardForm'
import { ProductImage } from '../components/ProductCard'
import './checkout.css'


function Checkout() {
  const navigate = useNavigate()
  const { items, clearCart, removeFromCart, updateQuantity } = useCart()
  const { address, setAddress } = useAddress()
  const { card, setCard } = usePayment()

  const [editingAddress, setEditingAddress] = useState(false)
  const [editingCard, setEditingCard] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const shippingFee = items.reduce((sum, item) => sum + (item.shippingCost || 0) * item.quantity, 0)
  const total = subtotal + shippingFee
  const unknownShipping = items.some(item => item.shippingCost == null)

  function formatAddress(addr) {
    return `${addr.line1}, ${addr.suburb}, ${addr.city}, ${addr.postalCode}`
  }

  async function handlePlaceOrder() {
    setError('')

    if (items.length === 0) {
      setError('Your cart is empty.')
      return
    }
    if (!address) {
      setError('Please add a shipping address before placing your order.')
      return
    }
    if (!card) {
      setError('Please add a payment card before placing your order.')
      return
    }

    setBusy(true)
    try {
      const result = await orderApi.checkout({
        items: items.map((item) => ({
          externalId: item.externalId,
          name: item.name,
          imageUrl: item.imageUrl || null,
          price: item.price,
          quantity: item.quantity,
        })),
        shippingAddress: formatAddress(address),
        shippingCost: shippingFee,
        paymentMethod: `Card ending ${card.last4}`,
      })

      if (!result.allowed) {
        navigate('/budget-alert', { state: { alert: result.alert } })
        return
      }

      clearCart()
      navigate(`/orders/${result.order.orderId}`, { replace: true })
    } catch (err) {
      setError(err.message || 'Could not place order.')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="checkout-page">
      <div className="checkout-header">
        <button className="back-arrow" onClick={() => navigate(-1)}>←</button>
        <h1>Checkout</h1>
      </div>

      <div className="checkout-content">
        <section className="checkout-section">
          <div className="section-row">
            <h2>Shipping Address</h2>
            <button className="change-link" onClick={() => setEditingAddress((v) => !v)}>
              {address ? 'Change' : 'Add'}
            </button>
          </div>
          {editingAddress ? (
            <AddressForm
              initialAddress={address}
              onSave={(newAddress) => {
                setAddress(newAddress)
                setEditingAddress(false)
              }}
              onCancel={() => setEditingAddress(false)}
            />
          ) : address ? (
            <p className="address-text">{formatAddress(address)}</p>
          ) : (
            <p className="empty-text">No saved address. Please add one to continue.</p>
          )}
        </section>

        <section className="checkout-section">
          <h2>Order Summary</h2>
          {items.length === 0 ? (
            <p className="empty-text">Your cart is empty.</p>
          ) : (
            items.map((item) => (
              <div className="order-item" key={item.externalId}>
                <ProductImage product={item} className="order-item-image" />
                <div className="order-item-info">
                  <p className="order-item-name">{item.name}</p>
                  {item.seller && <p className="order-item-seller">{item.seller}</p>}
                  <label className="order-item-qty">Qty: <input aria-label={`Quantity for ${item.name}`} type="number" min="1" max="99" value={item.quantity} disabled={busy} onChange={e => updateQuantity(item.externalId, Math.max(1, Math.min(99, Number(e.target.value))))} /></label>
                  <button className="change-link" disabled={busy} onClick={() => removeFromCart(item.externalId)}>Remove</button>
                </div>
                <p className="order-item-price">R{(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))
          )}
        </section>

        <section className="checkout-section">
          <div className="summary-row">
            <span>Subtotal</span>
            <span>R{subtotal.toFixed(2)}</span>
          </div>
          <div className="summary-row">
            <span>Shipping</span>
            <span>{unknownShipping ? 'Not confirmed' : shippingFee === 0 ? 'Free' : `R${shippingFee.toFixed(2)}`}</span>
          </div>
          <div className="summary-row total-row">
            <span>Total</span>
            <span>R{total.toFixed(2)}</span>
          </div>
        </section>

        <section className="checkout-section">
          <div className="section-row">
            <h2>Payment Method</h2>
            <button className="change-link" onClick={() => setEditingCard((v) => !v)}>
              {card ? 'Change' : 'Add'}
            </button>
          </div>
          {editingCard ? (
            <CardForm
              onSave={(newCard) => {
                setCard(newCard)
                setEditingCard(false)
              }}
              onCancel={() => setEditingCard(false)}
            />
          ) : card ? (
            <p className="payment-text">•••• •••• •••• {card.last4}</p>
          ) : (
            <p className="empty-text">No saved card. Please add one to continue.</p>
          )}
        </section>

        {error && <p className="checkout-error">{error}</p>}

        <p className="empty-text">Student project checkout: no payment is charged.</p>
        {unknownShipping && <p role="alert">Shipping is unavailable for an item. Check its retailer or remove it to continue.</p>}
        <button className="primary-button full-width" onClick={handlePlaceOrder} disabled={busy || items.length === 0 || unknownShipping}>
          {busy ? 'Placing Order…' : 'Place Order'}
        </button>
      </div>
    </div>
  )
}

export default Checkout
