import { useEffect, useState } from "react";
import { getDashboardSummary } from "../services/dashboardService";
import BudgetCard from "../components/BudgetCard";
import QuickActions from "../components/QuickActions";
import PromoBanner from "../components/PromoBanner";
import BottomNavigation from "../components/BottomNavigation";
import "./HomeDashboard.css";
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function HomeDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const data = await getDashboardSummary();
        setDashboard(data);
      } catch (err) {
        if (err.status === 404) { navigate('/budget', { replace: true }); return; }
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, [navigate]);

  if (loading) {
    return <p>Loading dashboard...</p>;
  }

  if (error) {
    return <main className="shop-page"><p role="alert">{error}</p><Link to="/budget">Set your budget</Link></main>;
  }

  return (
    <main className="home-dashboard">
      <section className="home-dashboard__content">
        <header className="home-dashboard__header">
          <h1>Hi, {user.firstName}! 👋</h1>
          <p>Let's shop smart today.</p>
        </header>

        <BudgetCard
          budget={dashboard.budget}
          spent={dashboard.spent}
          remaining={dashboard.remaining}
          remainingPercentage={dashboard.remainingPercentage}
        />

        <QuickActions />

        <PromoBanner />

        <BottomNavigation />
      </section>
    </main>
  );
}

export default HomeDashboard;
