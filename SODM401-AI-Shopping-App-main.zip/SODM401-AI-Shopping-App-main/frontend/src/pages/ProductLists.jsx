import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import ProductCard from '../components/ProductCard'
import useApi from '../hooks/useApi'
import { SearchForm } from './Search'
import { money, productPath } from '../services/format'

export default function ProductLists({ mode = 'results' }) {
  const [params, setParams] = useSearchParams()
  const resultLimit = Math.min(50, Math.max(20, Number(params.get("limit")) || 20))
  const [sort, setSort] = useState('best')
  const [limit, setLimit] = useState(8)
  const path = mode === 'favourites' ? '/api/favourites' : mode === 'recommendations' ? `/api/recommendations?limit=${limit}` : `/api/products/${mode === 'compare' ? 'compare' : 'search'}?${params}`
  const { data, error, loading, reload } = useApi(path)
  const favourites = useApi('/api/favourites')
  const products = [...(mode === 'favourites' ? data || [] : data?.products || [])].map(product => ({
    ...product,
    favouriteId: product.favouriteId || favourites.data?.find(saved => saved.externalId === product.externalId)?.favouriteId,
  }))
  if (sort !== 'best') products.sort((a, b) => sort === 'low' ? a.price - b.price : b.price - a.price)
  const title = { results: 'Search Results', favourites: 'Favourites', recommendations: 'AI Recommendations', compare: 'Compare Prices' }[mode]
  return <ShopLayout title={title}>{mode === 'results' && <><SearchForm initial={params.get('q') || ''} /><div className="row"><Link to={`/filters?${params}`}>Filters</Link><label>Sort by <select value={sort} onChange={e => setSort(e.target.value)}><option value="best">Best match</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></label></div></>}{mode === 'recommendations' && <div className="recommendation-banner">✦ Suggestions based on your favourites and remaining budget.<p>{data && `${money(data.remainingBudget)} remaining`}</p></div>}{data?.source === 'demo' && <p className="demo-note">Retailer catalogue snapshot · 28 Sep 2026. Confirm current price and availability at the retailer. Checkout is a demo.</p>}{loading && <p role="status">Loading products…</p>}{error && <p role="alert">{error} <button onClick={reload}>Try again</button></p>}{!loading && !error && <p className="muted">{products.length} {mode === 'favourites' ? 'saved products' : 'results shown'}</p>}{!loading && !error && products.length === 0 && <div className="shop-card"><p>{mode === 'favourites' ? 'Save a product using its heart button to find it here.' : 'No products match. Try a different search or clear your filters.'}</p><Link to="/search">Search products</Link></div>}<div className="product-list">{products.map(product => mode === 'compare' ? <article className="shop-card" key={product.externalId}><h3>{product.seller || 'Retailer'}</h3><p>{product.name}</p><div className="row"><strong className="price">{money(product.price)}</strong><Link className="shop-primary" to={productPath(product)}>View</Link></div><small>{product.externalId.startsWith('DEMO-RETAIL-') ? 'Delivery confirmed by retailer' : product.shippingCost == null ? 'Shipping not supplied' : product.shippingCost === 0 ? 'Free shipping' : `${money(product.shippingCost)} shipping`}</small></article> : <ProductCard key={`${product.externalId}:${product.favouriteId || "unsaved"}`} product={product} onRemoved={() => { reload(); favourites.reload() }} />)}</div>{mode === 'results' && !loading && !error && products.length >= resultLimit && resultLimit < 50 && <button className="shop-secondary" onClick={() => { const next = new URLSearchParams(params); next.set('limit', String(Math.min(50, resultLimit + 20))); setParams(next) }}>Show more products</button>}{mode === 'recommendations' && limit < 20 && <button className="shop-secondary" onClick={() => setLimit(20)}>View More Recommendations</button>}</ShopLayout>
}
