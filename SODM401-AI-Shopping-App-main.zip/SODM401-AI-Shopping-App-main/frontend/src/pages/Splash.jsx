import { useNavigate } from 'react-router-dom'
import './Splash.css'

function Splash() {
  const navigate = useNavigate()

  return (
    <div className="splash-page">
      <div className="splash-content">

        <div className="logo" aria-label="SmartShop logo">
          🛒
        </div>

        <h1>SmartShop</h1>

        <p className="tagline">
          Shop smart. Save more.
        </p>

        <div className="bottom-section">

          <button
            type="button"
            className="get-started"
            onClick={() => navigate('/login')}
          >
            Get Started
          </button>

          <p className="login-text">
            Already have an account?{' '}
            <button
              type="button"
              className="login-link"
              onClick={() => navigate('/login')}
            >
              Log in
            </button>
          </p>

        </div>

      </div>
    </div>
  )
}

export default Splash