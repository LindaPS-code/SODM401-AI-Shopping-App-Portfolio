import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import ShopLayout from '../components/ShopLayout'
import { ProductImage } from '../components/ProductCard'
import { useCart } from '../context/CartContext'
import useApi from '../hooks/useApi'
import { apiFetch } from '../services/api'
import { money } from '../services/format'

export default function ProductDetails() {
  const { id } = useParams()
  const { data: product, error, loading } = useApi(`/api/products/details?externalId=${encodeURIComponent(id)}`)
  const { addToCart } = useCart()
  const navigate = useNavigate()
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  async function favourite() {
    setBusy(true)
    try { await apiFetch('/api/favourites', { method: 'POST', body: JSON.stringify(product) }); setMessage('Saved to favourites.') }
    catch (err) { setMessage(err.message) } finally { setBusy(false) }
  }
  return <ShopLayout title="Product Details">{loading && <p>Loading product…</p>}{error && <p role="alert">{error}</p>}{product && <><ProductImage product={product} className="detail-image" /><h2>{product.name}</h2><p>{product.condition}</p><h2 className="price">{money(product.price)}</h2><section className="shop-card"><h3>Retailer</h3><p>{product.seller}</p><p className="green">{product.externalId.startsWith('DEMO-RETAIL-') ? 'Delivery costs confirmed by retailer; demo checkout uses R0.' : product.shippingCost === 0 ? 'Free shipping' : product.shippingCost == null ? 'Shipping confirmed by retailer' : `${money(product.shippingCost)} shipping`}</p>{product.productUrl && /^https?:\/\//i.test(product.productUrl) && <a href={product.productUrl} target="_blank" rel="noreferrer">View product at retailer ↗</a>}</section><h3>Description</h3><p>{product.description || 'No additional description supplied.'}</p><Link className="shop-secondary" to={`/compare?q=${encodeURIComponent(product.name)}`}>Compare prices</Link><div className="row"><button className="shop-primary" onClick={() => { addToCart(product); navigate('/checkout') }}>Add to Cart</button><button className="shop-secondary" disabled={busy} onClick={favourite}>♡ Save</button></div>{message && <p role="status">{message}</p>}</>}</ShopLayout>
}
