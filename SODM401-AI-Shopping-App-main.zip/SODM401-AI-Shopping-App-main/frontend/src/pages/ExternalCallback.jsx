import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { apiFetch } from '../services/api'

export default function ExternalCallback() {
  const navigate = useNavigate()
  const { acceptSession } = useAuth()
  const started = useRef(false)
  const [error, setError] = useState('')
  useEffect(() => {
    // StrictMode must not redeem the same one-use code twice.
    if (started.current) return
    started.current = true
    const code = new URLSearchParams(window.location.hash.slice(1)).get('code')
    window.history.replaceState(null, '', '/auth/callback')
    async function complete() {
      if (!code) throw new Error('The sign-in link expired. Please try again.')
      const result = await apiFetch('/api/auth/external/exchange', { method: 'POST', body: JSON.stringify({ code }) })
      acceptSession(result)
      try { await apiFetch('/api/budgets/current'); navigate('/dashboard', { replace: true }) }
      catch (err) { if (err.status === 404) navigate('/budget', { replace: true }); else throw err }
    }
    complete().catch(err => setError(err.message))
  }, [acceptSession, navigate])
  return <main className="shop-page"><h1>Completing sign-in</h1>{error ? <><p role="alert">{error}</p><Link to="/login">Back to login</Link></> : <p role="status">Signing you in…</p>}</main>
}
