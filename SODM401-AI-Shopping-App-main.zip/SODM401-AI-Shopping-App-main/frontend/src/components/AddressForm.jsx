import { useState } from 'react'

function AddressForm({ initialAddress, onSave, onCancel }) {
  const [line1, setLine1] = useState(initialAddress?.line1 || '')
  const [suburb, setSuburb] = useState(initialAddress?.suburb || '')
  const [city, setCity] = useState(initialAddress?.city || '')
  const [postalCode, setPostalCode] = useState(initialAddress?.postalCode || '')
  const [error, setError] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (!line1.trim() || !suburb.trim() || !city.trim() || !postalCode.trim()) {
      setError('Please fill in all fields.')
      return
    }
    if (!/^\d{4}$/.test(postalCode.trim())) {
      setError('Postal code must be 4 digits.')
      return
    }
    onSave({ line1: line1.trim(), suburb: suburb.trim(), city: city.trim(), postalCode: postalCode.trim() })
  }

  return (
    <form className="inline-form" onSubmit={handleSubmit}>
      <label>
        Street Address
        <input value={line1} onChange={(e) => setLine1(e.target.value)} placeholder="123 University Rd" />
      </label>
      <label>
        Suburb
        <input value={suburb} onChange={(e) => setSuburb(e.target.value)} placeholder="Auckland Park" />
      </label>
      <label>
        City
        <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="Johannesburg" />
      </label>
      <label>
        Postal Code
        <input
          value={postalCode}
          onChange={(e) => setPostalCode(e.target.value.replace(/\D/g, '').slice(0, 4))}
          placeholder="2006"
          inputMode="numeric"
        />
      </label>
      {error && <p className="form-error">{error}</p>}
      <div className="form-actions">
        <button type="button" className="secondary-button" onClick={onCancel}>Cancel</button>
        <button type="submit" className="primary-button">Save Address</button>
      </div>
    </form>
  )
}

export default AddressForm