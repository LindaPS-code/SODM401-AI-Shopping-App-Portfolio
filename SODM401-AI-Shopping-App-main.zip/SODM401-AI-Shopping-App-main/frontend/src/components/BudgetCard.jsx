import "./BudgetCard.css";

function BudgetCard({ budget, spent, remaining, remainingPercentage }) {
  return (
    <section className="budget-card">
      <div className="budget-card__top">
        <div>
          <p className="budget-card__label">My Budget</p>
          <h2>R{budget.toFixed(2)}</h2>
        </div>

        <div
          className="budget-card__progress"
          style={{
            background: `conic-gradient(
              #22a447 ${remainingPercentage}%,
              #e6e6e6 ${remainingPercentage}% 100%
            )`,
          }}
        >
          <div className="budget-card__progress-inner">
            <strong>{remainingPercentage.toFixed(0)}%</strong>
            <span>Remaining</span>
          </div>
        </div>
      </div>

      <div className="budget-card__bottom">
        <div>
          <span>Remaining</span>
          <strong className="remaining">R{remaining.toFixed(2)}</strong>
        </div>

        <div>
          <span>Spent</span>
          <strong className="spent">R{spent.toFixed(2)}</strong>
        </div>
      </div>
    </section>
  );
}

export default BudgetCard;
