import { useState } from 'react'
import demoImages from '../data/demoImages.json'
import { Link } from 'react-router-dom'
import { apiFetch } from '../services/api'
import { money, productPath } from '../services/format'

export function ProductImage({ product, className = '' }) {
  const [failedUrl, setFailedUrl] = useState(null)
  const imageUrl = demoImages[product.externalId] || (product.externalId?.startsWith('DEMO-') && !product.externalId.startsWith('DEMO-RETAIL-') ? null : product.imageUrl)
  return imageUrl && failedUrl !== imageUrl ? <img className={className} src={imageUrl} loading="lazy" decoding="async" alt={product.name} onError={() => setFailedUrl(imageUrl)} /> : <div className={`product-placeholder ${className}`} aria-label="Product image unavailable">🛍<small>Image unavailable</small></div>
}
export default function ProductCard({ product, onRemoved }) {
  const [savedId, setSavedId] = useState(product.favouriteId)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  async function toggle() {
    setBusy(true); setError('')
    try {
      if (savedId) { await apiFetch(`/api/favourites/${savedId}`, { method: 'DELETE' }); setSavedId(null); onRemoved?.() }
      else { const saved = await apiFetch('/api/favourites', { method: 'POST', body: JSON.stringify(product) }); setSavedId(saved.favouriteId) }
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }
  return <article className="product-card"><Link className="product-link" to={productPath(product)}><ProductImage product={product} /><div><h3>{product.name}</h3><p className="muted">{product.seller}</p><strong className="price">{money(product.price)}</strong>{product.withinBudget && <small className="green">Within your budget</small>}</div></Link><button className="heart" aria-label={savedId ? `Remove ${product.name} from favourites` : `Save ${product.name} to favourites`} aria-pressed={!!savedId} onClick={toggle} disabled={busy}>{savedId ? '♥' : '♡'}</button>{error && <p role="alert">{error}</p>}</article>
}
