import { useState } from 'react'

function formatCardNumber(value) {
  const digits = value.replace(/\D/g, '').slice(0, 16)
  return digits.replace(/(.{4})/g, '$1 ').trim()
}

function formatExpiry(value) {
  const digits = value.replace(/\D/g, '').slice(0, 4)
  if (digits.length <= 2) return digits
  return `${digits.slice(0, 2)}/${digits.slice(2)}`
}

function CardForm({ onSave, onCancel }) {
  const [cardNumber, setCardNumber] = useState('')
  const [expiry, setExpiry] = useState('')
  const [cvv, setCvv] = useState('')
  const [nameOnCard, setNameOnCard] = useState('')
  const [error, setError] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    const digitsOnly = cardNumber.replace(/\D/g, '')

    if (!nameOnCard.trim()) {
      setError('Name on card is required.')
      return
    }
    if (digitsOnly.length !== 16) {
      setError('Card number must be exactly 16 digits.')
      return
    }
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      setError('Expiry date must be in MM/YY format.')
      return
    }
    const [month, year] = expiry.split('/').map(Number)
    if (month < 1 || month > 12) {
      setError('Expiry month must be between 01 and 12.')
      return
    }
    const now = new Date()
    const currentYear = now.getFullYear() % 100
    const currentMonth = now.getMonth() + 1
    if (year < currentYear || (year === currentYear && month < currentMonth)) {
      setError('Card has expired.')
      return
    }
    if (!/^\d{3}$/.test(cvv)) {
      setError('CVV must be exactly 3 digits.')
      return
    }

    onSave({
      nameOnCard: nameOnCard.trim(),
      last4: digitsOnly.slice(-4),
      expiry,
    })
  }

  return (
    <form className="inline-form" onSubmit={handleSubmit}>
      <label>
        Name on Card
        <input value={nameOnCard} onChange={(e) => setNameOnCard(e.target.value)} placeholder="Sanele M." />
      </label>
      <label>
        Card Number
        <input
          value={cardNumber}
          onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
          placeholder="1234 5678 9012 3456"
          inputMode="numeric"
        />
      </label>
      <div className="form-row">
        <label>
          Expiry (MM/YY)
          <input
            value={expiry}
            onChange={(e) => setExpiry(formatExpiry(e.target.value))}
            placeholder="12/28"
            inputMode="numeric"
          />
        </label>
        <label>
          CVV
        <input
          type="password" autoComplete="off"
          value={cvv}
            onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
            placeholder="123"
            inputMode="numeric"
          />
        </label>
      </div>
      {error && <p className="form-error">{error}</p>}
      <div className="form-actions">
        <button type="button" className="secondary-button" onClick={onCancel}>Cancel</button>
        <button type="submit" className="primary-button">Save Card</button>
      </div>
    </form>
  )
}

export default CardForm
