import { Link } from 'react-router-dom'
import BottomNavigation from './BottomNavigation'

export default function ShopLayout({ title, children }) {
  return <main className="shop-page"><header className="shop-heading"><Link to="/dashboard" aria-label="Home">‹</Link><h1>{title}</h1><Link to="/checkout" aria-label="Shopping cart">🛒</Link></header>{children}<BottomNavigation /></main>
}
