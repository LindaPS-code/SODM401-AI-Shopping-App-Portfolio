import "./QuickActions.css";
import { useNavigate } from 'react-router-dom';

function QuickActions() {
  const navigate = useNavigate();
  const paths = { Search: '/search', 'AI Recommendations': '/recommendations', Favourites: '/favourites', 'Budget History': '/budget/history' };
  const actions = [
    {
      label: "Search",
      icon: "🔍",
    },
    {
      label: "AI Recommendations",
      icon: "✨",
    },
    {
      label: "Favourites",
      icon: "❤️",
    },
    {
      label: "Budget History",
      icon: "📊",
    },
  ];

  return (
    <section className="quick-actions">
      <h2 className="quick-actions__title">Quick Actions</h2>

      <div className="quick-actions__grid">
        {actions.map((action) => (
          <button key={action.label} type="button" className="quick-action" onClick={() => navigate(paths[action.label])}>
            <span className="quick-action__icon">{action.icon}</span>

            <span className="quick-action__label">{action.label}</span>
          </button>
        ))}
      </div>
    </section>
  );
}

export default QuickActions;
