import "./BottomNavigation.css";
import { useLocation, useNavigate } from 'react-router-dom';

function BudgetIcon() {
  return (
    <svg
      className="bottom-navigation__svg"
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M5 9H19L18 20H6L5 9Z"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinejoin="round"
      />

      <path
        d="M9 9V7C9 5.34 10.34 4 12 4C13.66 4 15 5.34 15 7V9"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />

      <path
        d="M12 12V17"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />

      <path
        d="M13.5 13.2C13.5 12.54 12.83 12 12 12C11.17 12 10.5 12.54 10.5 13.2C10.5 13.86 11.17 14.4 12 14.4C12.83 14.4 13.5 14.94 13.5 15.6C13.5 16.26 12.83 16.8 12 16.8C11.17 16.8 10.5 16.26 10.5 15.6"
        stroke="currentColor"
        strokeWidth="1.3"
        strokeLinecap="round"
      />
    </svg>
  );
}

function BottomNavigation() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const paths = { Home: '/dashboard', Search: '/search', Favourites: '/favourites', Budget: '/budget', Profile: '/profile' };
  const items = [
    {
      label: "Home",
      icon: "🏠",
      active: true,
    },
    {
      label: "Search",
      icon: "🔍",
    },
    {
      label: "Favourites",
      icon: "♡",
    },
    {
      label: "Budget",
      customIcon: <BudgetIcon />,
    },
    {
      label: "Profile",
      icon: "👤",
    },
  ];

  return (
    <nav className="bottom-navigation">
      {items.map((item) => (
        <button
          key={item.label}
          type="button"
          onClick={() => navigate(paths[item.label])}
          className={`bottom-navigation__item ${
            pathname.startsWith(paths[item.label]) ? "bottom-navigation__item--active" : ""
          }`}
        >
          <span className="bottom-navigation__icon">
            {item.customIcon || item.icon}
          </span>

          <span className="bottom-navigation__label">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

export default BottomNavigation;
