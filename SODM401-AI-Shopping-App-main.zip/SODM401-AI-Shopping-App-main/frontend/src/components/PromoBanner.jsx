import "./PromoBanner.css";

function PromoBanner() {
  return (
    <section className="promo-banner">
      <div className="promo-banner__content">
        <h3>Shop smart. Save more.</h3>
        <p>Find the best deals that fit your budget.</p>
      </div>

      <div className="promo-banner__icon" aria-hidden="true">
        🛍️
      </div>
    </section>
  );
}

export default PromoBanner;
