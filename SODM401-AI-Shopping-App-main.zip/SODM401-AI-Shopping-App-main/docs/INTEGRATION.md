# SmartShop integration map

Reference: the supplied 14-screen mockup and execution brief. The project report was not attached.

Initial Git state: `feature/home-dashboard`, with 52 staged files and additional solution/config changes. Local main is behind cached origin/main, which includes checkout. Three stashes remain intact. Filter JSX/CSS and service were recovered individually from stash 0's untracked tree; generated files and branch changes were not restored. No existing changes were reset or staged by this integration.

| Screen | Initial state / visual basis | Route | API and remaining integration work at assessment |
| --- | --- | --- | --- |
| 1 Splash | Existing green SmartShop design | / | Public; preserve navigation |
| 2 Login / Signup | Existing mock-based forms, inactive submit | /login, /signup | Public POST auth/login and auth/register; save JWT and profile |
| 3 Set Budget | Missing in current frontend | /budget | Protected GET/PUT budgets/current; slider and summary |
| 4 Dashboard | Existing cards; obsolete user 1 API | /dashboard | Protected budgets/current; map DTO and wire actions |
| 5 Search | Missing | /search | Protected screen; popular-searches and categories |
| 6 Results | Missing | /results | Protected products/search; URL query state and sorting |
| 7 Filters | Complete design in stash; console-only apply | /filters | Protected products/search; preserve design, apply URL filters |
| 8 Compare | Missing | /compare | Protected products/compare; seller, price, shipping |
| 9 Details | Missing | /products/:id | Protected products/details; favourites and cart |
| 10 Recommendations | Backend only | /recommendations | Protected recommendations; budget-aware product list |
| 11 Favourites | Backend only | /favourites | Protected GET/POST/DELETE favourites |
| 12 Budget Alert | Backend response only | /budget-alert | Protected; current budget, cart total and checkout alert |
| 13 Checkout | Existing teammate implementation | /checkout | Protected orders/checkout; correct allowed/alert contract, shipping and cart controls |
| 14 Confirmation | Inline success with wrong contract | /orders/:id | Protected orders/:id; persisted confirmation |

Supporting routes: /budget/history and /profile. All protected routes use the current JWT. Current application: frontend/ and root SmartShop.Api.csproj; backend/ShoppingApp.Api is retained historical work.

External limits: Google/Apple sign-in and password recovery have no backend implementation. Orders are university-project records, not actual retailer purchases or card charges; email dispatch is not implemented. eBay has its existing explicit demo fallback. Recommendations use the existing Ollama service and keyword fallback. Demo results must be labelled. No product database is introduced.

## Implemented and verified

- All 14 screens have navigable routes; existing splash/auth/dashboard/checkout designs were retained and the stash's filter design restored selectively.
- Authenticated budget API replaces hard-coded user 1. All protected requests use the same JWT client, with expired-session handling.
- Cart, address and masked payment summary are scoped to each account. Unknown routes recover to the splash screen.
- Product queries and filters persist in URLs. Empty results remain empty instead of silently dropping colour/size constraints. Demo results are visibly labelled.
- Checkout uses `allowed`/`alert`, verifies provider prices and shipping, rejects invalid quantities and serializes budget updates. Order confirmation reloads from the user's saved order.
- Backend build: passed, zero warnings/errors. Frontend production build and ESLint: passed.
- Real LocalDB API smoke test: passed registration/login, missing budget/setup, search, filters, compare, favourites, tampered-price rejection, over-budget rejection, order retrieval, spending update, cross-user isolation and budget-aware recommendations.
- Browser: verified login, dashboard and restored filter navigation; additional visual checks are recorded below.

No commits, pushes, merges, stash pops or resets were performed. Changes remain reviewable on the original branch, alongside the pre-existing staged work.
- Browser end-to-end check completed with a test account: login → dashboard → filtered backpack search → favourite → product details → cart → test address/card forms → simulated checkout → persisted order confirmation. Updating the monthly budget changed the dashboard totals. An additional R699 cart with R454 remaining opened Budget Alert showing R245 shortfall. Confirmation and budget layouts were inspected at 390×844.
- Final production build and lint passed after the browser fixes. Modified-file whitespace check passed excluding the user's pre-existing solution/config whitespace changes.

## Files changed by this integration

- Routing/session: frontend/src/App.jsx, context/AuthContext.jsx, services/api.js; account-scoped CartContext, AddressContext and PaymentContext.
- Existing UI integrated: Login, SignUp, HomeDashboard, checkout, BottomNavigation, QuickActions and CardForm.
- Added UI: Budget/BudgetHistory, Search, ProductLists (results/compare/favourites/recommendations), ProductDetails, BudgetAlert, OrderConfirmation, Profile; ShopLayout, ProductCard and Shop.css.
- Recovered stash: FiltersPage.jsx, FiltersPage.css and productService.js (updated for current authentication/API).
- Backend: AuthController input validation; OrdersController provider pricing/shipping and budget transaction; EbayProductService shipping filters/demo query handling; DemoCatalog empty-result correctness; SmartShop.Api.csproj build exclusions.
- Setup and checks: frontend/vite.config.js, frontend/index.html, root package scripts, frontend lockfile, README.md and scripts/smoke-api.mjs.

## Remaining differences from the mockup

Product names, prices and imagery depend on the provider/demo catalogue, rather than the exact static mock products. Icons use the existing project's emoji style. There is no voice search, additional-colour expansion, OAuth, password-reset service, email confirmation or real payment/retailer-order integration. Unsupported controls are disabled, removed or explain the limitation. Recommendation copy describes favourites and budget because browsing-history tracking is not implemented in the current backend. These integrations need a requirements decision and/or external service configuration; none is silently simulated as a completed external action.

## Deployment preparation checkpoint

The integrated MVP was committed as b1e76dd, completing the merge that was already in progress on feature/home-dashboard. Further work is on codex/team-demo; main has not been modified.

Google/Apple OpenID Connect integration, a browser-bound single-use JWT handoff, safe additive ExternalLogins schema setup, production configuration, combined React/API publishing, a Dockerfile, GitHub build/manual Azure workflows and temporary demo start/stop scripts have been added. Provider credentials are still absent, so neither social provider is activated or live-tested. See DEPLOYMENT.md for the exact remaining account setup.

Validated: frontend build/lint; .NET build/publish; authentication handoff/configuration checks; full API smoke test against the separate SmartShopTeamDemo database; public HTTPS health, client-side deep links and email/password login to the dashboard. A temporary Cloudflare link runs from the laptop; permanent Azure hosting has not been provisioned. The starter keeps the normal SmartShopDb private and generates an independent random signing key. Local artifact/process files and helper binaries are ignored by Git.
