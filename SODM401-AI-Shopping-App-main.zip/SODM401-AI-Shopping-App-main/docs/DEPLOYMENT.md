# Team demo and hosting

## Temporary demo

The temporary link is recorded locally in `artifacts/demo-runtime/state.json`. It uses Cloudflare Quick Tunnel and a separate SQL Server LocalDB database, `SmartShopTeamDemo`. The normal `SmartShopDb` data is not exposed. The public instance starts with no seeded accounts; each teammate should sign up and set a budget. Use test information only: checkout records simulated orders and makes no payment or retailer purchase.

The computer must remain awake and connected to the internet. Closing the browser is fine; shutting down, sleeping or terminating the background processes stops the demo. Cloudflare does not guarantee availability for Quick Tunnels. Restarting creates a new URL and a new JWT signing key, so users must sign in again; database accounts and orders persist.

- Start: run `./scripts/start-team-demo.ps1` in PowerShell after building the package and downloading the verified Cloudflare executable.
- Stop: run `./scripts/stop-team-demo.ps1`. This stops only the recorded process IDs whose start times still match, and preserves the database.
- Logs and process metadata: ignored `artifacts/demo-runtime/`.
- The starter verifies cloudflared 2026.9.3 against its official release SHA-256 before execution.

## Permanent host: Azure App Service + Azure SQL

This keeps the required React, ASP.NET Core and SQL Server architecture. An Azure subscription must be created by the account owner before deployment; no Azure resources have been purchased or provisioned. Eligible students can investigate Azure for Students. Review the selected region, plan, available student credit and quoted cost before creating resources.

1. Create an App Service supporting .NET 8 and an Azure SQL database. Keep HTTPS-only enabled. The current demo should run as a single instance (external-login handoff codes are stored briefly in process memory).
2. Configure the SQL firewall/network rules so the App Service can reach the database. Use a dedicated database credential with access only to this app's database. The current university-project initializer needs schema-create permission on first startup and adds `ExternalLogins` to existing MVP databases without deleting data.
3. Add these App Service environment settings; never commit their real values:

| Setting | Value |
| --- | --- |
| `ASPNETCORE_ENVIRONMENT` | `Production` |
| `ConnectionStrings__DefaultConnection` | Azure SQL connection string with encryption enabled |
| `Jwt__Key` | A private, random key of at least 32 bytes |
| `Authentication__FrontendOrigin` | The app's HTTPS origin, without a trailing slash |
| `SeedDemoUsers` | `false` |
| `ASPNETCORE_FORWARDEDHEADERS_ENABLED` | `true` for Azure App Service's trusted front-end proxy |

4. Build with `./scripts/publish-demo.ps1 -OutputDirectory artifacts/azure-demo`. This installs the locked frontend dependencies, lints/builds, publishes .NET, adds the frontend into `wwwroot`, and creates a ZIP. Choose a new output directory for each run; the script refuses to reuse stale publish output.
5. Deploy the ZIP contents to App Service. The default Linux startup command is `dotnet SmartShop.Api.dll`. Alternatively, the repository's manual `Deploy Azure demo` workflow accepts an existing App Service name and requires `AZURE_WEBAPP_PUBLISH_PROFILE` as a GitHub Actions secret. Do not run it until that existing host has been configured.
6. Check `/api/health`, register a test user, set a budget, search, save a favourite and place a simulated order. Reload `/dashboard` directly to verify client-route fallback.

The React app and API share one host, avoiding public frontend-to-localhost requests and cross-site cookies. No `VITE_API_BASE_URL` is needed. eBay credentials and Ollama remain optional; their existing demo/keyword fallbacks remain explicit.

## Google sign-in

Requires a Google Cloud project and an OAuth web application client. The account owner must complete any account setup or provider terms.

1. Configure the consent screen and add the team's test users when using Google's testing mode.
2. Register the exact callback `https://YOUR-HOST/api/auth/callback/google`. Local testing can use `http://localhost:5173/api/auth/callback/google` through the Vite proxy.
3. Set `Authentication__Google__ClientId` and `Authentication__Google__ClientSecret` in the host's secret settings. For local use, use .NET user-secrets.
4. Restart the API. `/api/auth/external/providers` reports Google as enabled. Test consent, cancellation, first login, and a returning login.

## Apple sign-in

Requires the Apple developer configuration for web sign-in: a Sign in with Apple-enabled primary App ID, a linked Services ID, verified web-domain/return URL configuration, and a private key.

1. Register the exact HTTPS return URL `https://YOUR-HOST/api/auth/callback/apple` with Apple.
2. Generate Apple's signed client-secret JWT with the developer team's private key as documented by Apple. Store the signed secret as `Authentication__Apple__ClientSecret`; store the Services ID as `Authentication__Apple__ClientId`. Keep the `.p8` key private, outside source control.
3. Restart the API and test using the deployed HTTPS domain. Apple returns the authorization response through a cross-site form POST, so an HTTP localhost demo is insufficient.
4. Renew the signed client secret before its expiration. This version expects a supplied signed secret and does not rotate it automatically.

## Sign-in behaviour and validation limits

Provider discovery/validation uses Microsoft's OpenID Connect middleware with issuer/audience/signature, state and nonce validation. Google additionally uses PKCE. The backend identifies accounts by provider + subject and requires a verified provider email; it does not silently link an existing password account on matching email. If an email already exists, use the original sign-in method. A single-use browser-bound code exchanges for the existing application JWT; the JWT is never placed in a redirect URL. First-time social users proceed to budget setup.

Without credentials, clicking a provider explains that setup is pending; it does not fake a login. Automated checks cover handoff binding, replay prevention, unknown-code rejection and configuration gating. Live Google/Apple consent and callbacks remain unverified until real provider accounts/credentials are supplied. Regular email/password login remains available.

Sources: [Azure for Students](https://azure.microsoft.com/en-us/free/students/), [App Service ZIP deployment](https://learn.microsoft.com/en-us/azure/app-service/deploy-zip), [Google OpenID Connect](https://developers.google.com/identity/openid-connect/openid-connect), [Apple web sign-in configuration](https://developer.apple.com/documentation/signinwithapple/configuring-your-environment-for-sign-in-with-apple), [Cloudflare Quick Tunnels](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/do-more-with-tunnels/trycloudflare/).
