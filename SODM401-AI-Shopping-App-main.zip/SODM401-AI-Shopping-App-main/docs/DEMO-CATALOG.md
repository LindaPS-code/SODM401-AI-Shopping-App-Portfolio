# Retailer catalogue snapshot

The fallback catalogue contains real retailer product names, photos, prices and direct product-page links captured on 28 September 2026. It is a checked-in snapshot, not a live stock feed. Confirm current price, size availability and delivery at the retailer. Checkout remains a simulation; its zero shipping is not a retailer delivery quote. Locations and sizes are left unknown rather than fabricated.

Sources:
- https://superbalist.com/shop/nike-air-force
- https://superbalist.com/browse/men/accessories/bags-wallets
- https://superbalist.com/browse/women/beauty/skincare
- https://superbalist.com/browse/home-and-living/tabletop/kitchen
- https://exclusivebooks.co.za/collections/bestsellers/products.json?limit=20
- https://computermania.co.za/collections/headsets/products.json?limit=20

Retailer images belong to their respective owners and are used to identify the linked products. The exact source image and product URLs are recorded in Data/retailer-image-sources.json. No generated illustrations or DummyJSON offers are used in this catalogue.

For a reviewed refresh, save the source responses under artifacts/retailer-catalog as superbalist.html, bags.source, beauty.source, home.source, books.source and electronics.source; run node scripts/build-demo-catalog.mjs, download its downloads.json entries, and copy that manifest to Data/retailer-image-sources.json. Review changes before publishing. Normal builds are offline and use committed images and embedded JSON; the eBay live-provider integration remains available when credentials are configured.

Previous fabricated demo IDs are retired. Existing saved history is preserved, but those offers must be replaced from the current catalogue before checkout.
