namespace SmartShop.Api.Options;

public class JwtOptions
{
    public const string SectionName = "Jwt";

    public string Key { get; set; } = string.Empty;
    public string Issuer { get; set; } = "SmartShop";
    public string Audience { get; set; } = "SmartShop";
    public int ExpiresInMinutes { get; set; } = 120;
}

public class EbayOptions
{
    public const string SectionName = "Ebay";

    public bool UseSandbox { get; set; } = true;
    public string ClientId { get; set; } = string.Empty;
    public string ClientSecret { get; set; } = string.Empty;
    public string MarketplaceId { get; set; } = "EBAY_US";
    public decimal ZarPerUsd { get; set; } = 18.50m;
}

public class OllamaOptions
{
    public const string SectionName = "Ollama";

    public string BaseUrl { get; set; } = "http://localhost:11434";
    public string Model { get; set; } = "llama3.2";
}
