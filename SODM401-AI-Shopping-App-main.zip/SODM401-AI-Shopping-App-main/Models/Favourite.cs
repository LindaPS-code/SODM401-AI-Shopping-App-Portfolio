namespace SmartShop.Api.Models;

public class Favourite
{
    public int FavouriteId { get; set; }
    public int UserId { get; set; }
    public string ExternalId { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? ImageUrl { get; set; }
    public decimal Price { get; set; }
    public string Currency { get; set; } = "ZAR";
    public string? Seller { get; set; }
    public string? Location { get; set; }
    public string? ProductUrl { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public User User { get; set; } = null!;
}
