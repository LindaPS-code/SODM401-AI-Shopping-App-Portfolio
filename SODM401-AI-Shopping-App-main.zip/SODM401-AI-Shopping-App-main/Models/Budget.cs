namespace SmartShop.Api.Models;

public class Budget
{
    public int BudgetId { get; set; }
    public int UserId { get; set; }
    public decimal Amount { get; set; }
    public decimal SpentAmount { get; set; }
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public User User { get; set; } = null!;

    public decimal RemainingAmount => Amount - SpentAmount;

    public int PercentRemaining
    {
        get
        {
            if (Amount <= 0)
            {
                return 0;
            }

            var percent = (RemainingAmount / Amount) * 100m;
            if (percent < 0)
            {
                return 0;
            }

            return percent > 100 ? 100 : (int)Math.Round(percent, MidpointRounding.AwayFromZero);
        }
    }
}
