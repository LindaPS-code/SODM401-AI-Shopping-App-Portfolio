namespace SmartShop.Api.Models;

public class ExternalLogin
{
    public string Provider { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public int UserId { get; set; }
    public User User { get; set; } = null!;
}
