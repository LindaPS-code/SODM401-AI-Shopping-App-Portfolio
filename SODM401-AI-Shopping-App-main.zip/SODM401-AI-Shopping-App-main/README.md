# SmartShop — SODM401 AI Shopping App

React + JavaScript frontend, ASP.NET Core 8 API, SQL Server LocalDB and EF Core.

## Run locally

1. Install Node.js and the .NET SDK; SQL Server LocalDB must be available for your Windows user.
2. In `frontend`, run `npm install`, then `npm run dev`.
3. From the repository root, run `dotnet run --project SmartShop.Api.csproj --launch-profile http`.
4. Open http://localhost:5173. Create an account, set a budget, then search and shop.

The frontend proxies `/api` to http://localhost:5254. For another API host, set `VITE_API_BASE_URL` in a local frontend environment file. For hosting, configure the web server to forward `/api` and serve `index.html` for client routes. Add the deployed frontend origin to the backend CORS policy when hosting separately.

The root npm scripts forward to the integrated frontend. `backend/ShoppingApp.Api` is older dashboard work retained for reference; it is excluded from the current API build. The current database is `SmartShopDb`, not the older dashboard database. Existing data is not dropped. Initial schema creation uses the project's `EnsureCreated` setup, so an incompatible pre-existing schema requires a reviewed migration rather than deleting its database.

## Verify

- `npm run build` and `npm run lint` in `frontend`.
- `dotnet build SmartShop.Api.csproj` from the root.
- With the API running: `node scripts/smoke-api.mjs`. This creates uniquely named `@example.test` accounts and test orders in the local database. It does not modify existing users.

## Project boundaries

The API obtains products through the existing eBay service. Without credentials it returns the labelled demo catalogue. Demo catalogue image links are unavailable; the interface shows an explicit image placeholder rather than broken images. Demo items have limited size/colour metadata, so those filters may return no matches. Sample prices are not live retailer offers.

Recommendations use the existing Ollama service and its keyword fallback. Configure eBay credentials and Ollama locally; do not commit secrets. Google and Apple sign-in are wired through OpenID Connect but require provider credentials before activation; password recovery remains unavailable. Checkout records a project order and updates the budget; it does not charge cards, purchase from retailers or send email. Only the masked card summary is retained, never the full card number or CVV.

For temporary team sharing, Azure hosting and Google/Apple setup, see `docs/DEPLOYMENT.md`. Production requires an external SQL connection string and a private JWT key; development-only defaults are kept in `appsettings.Development.json`.

See `docs/INTEGRATION.md` for the 14-screen map and validation notes. The project report was not supplied; visual reference was the attached mockup.
