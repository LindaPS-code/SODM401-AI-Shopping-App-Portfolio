$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$statePath = Join-Path $projectRoot 'artifacts/demo-runtime/state.json'
if (-not (Test-Path $statePath)) { Write-Output 'No recorded demo process.'; exit }
$state = Get-Content -Raw $statePath | ConvertFrom-Json
foreach ($item in @($state.api, $state.tunnel)) {
    $process = Get-Process -Id $item.id -ErrorAction SilentlyContinue
    if ($process -and $process.StartTime.ToUniversalTime().ToString('o') -eq $item.started) {
        Stop-Process -Id $process.Id
    }
}
Write-Output 'The temporary demo has stopped. Its database has been preserved.'
