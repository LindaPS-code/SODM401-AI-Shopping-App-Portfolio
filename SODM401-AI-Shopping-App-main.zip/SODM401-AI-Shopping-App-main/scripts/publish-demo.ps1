param([string]$OutputDirectory = "artifacts/demo")
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$outputPath = [IO.Path]::GetFullPath((Join-Path $projectRoot $OutputDirectory))
if (-not $outputPath.StartsWith($projectRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The output directory must be inside the repository.'
}
if (Test-Path -LiteralPath $outputPath) {
    throw "Output already exists: $outputPath. Choose a new -OutputDirectory to avoid packaging stale files."
}
Push-Location (Join-Path $projectRoot 'frontend')
try {
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw 'Frontend dependency installation failed.' }
    & npm.cmd run lint
    if ($LASTEXITCODE -ne 0) { throw 'Frontend lint failed.' }
    & npm.cmd run build
    if ($LASTEXITCODE -ne 0) { throw 'Frontend build failed.' }
} finally { Pop-Location }
& dotnet publish (Join-Path $projectRoot 'SmartShop.Api.csproj') --configuration Release --output $outputPath
if ($LASTEXITCODE -ne 0) { throw 'API publish failed.' }
$webRoot = Join-Path $outputPath 'wwwroot'
New-Item -ItemType Directory -Path $webRoot -Force | Out-Null
Copy-Item -Path (Join-Path $projectRoot 'frontend/dist/*') -Destination $webRoot -Recurse
Compress-Archive -Path (Join-Path $outputPath '*') -DestinationPath ($outputPath + '.zip')
Write-Output "Deployment package: $outputPath.zip"
Write-Output 'Configure the SQL connection, private JWT key and frontend origin in the hosting service before startup.'
