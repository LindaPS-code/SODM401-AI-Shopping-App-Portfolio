// Build the checked-in retailer snapshot from public structured product data.
// See docs/DEMO-CATALOG.md for source URLs and refresh instructions.
import fs from 'node:fs'
import path from 'node:path'
const root=path.resolve(import.meta.dirname,'..')
const read=name=>fs.readFileSync(path.join(root,'artifacts/retailer-catalog',name),'utf8')
const entries=[]; const downloads=[]
function add(id,name,price,image,url,seller,category,tags=[]){
 if(!image||!url||!Number.isFinite(price)||price<=0)return
 const local=`/products/retailer-${id}.jpg`
 const colours=['White','Black','Blue','Red','Pink','Brown','Green','Grey','Beige'].filter(c=>(name+' '+url).toLowerCase().includes(c.toLowerCase()))
 entries.push({product:{externalId:`DEMO-RETAIL-${id}`,name,imageUrl:local,price,currency:'ZAR',seller,location:null,productUrl:url,shippingCost:0,withinBudget:null},category,tags,colours,sizes:[],description:'Retailer product and photograph. Price snapshot captured 28 September 2026; confirm current price, sizes, stock and delivery on the linked retailer page. SmartShop checkout is a demonstration only; its R0 shipping does not represent retailer delivery charges.'})
 downloads.push({url:image,file:`frontend/public${local}`,productUrl:url})
}
for(const [file,category,tags,max] of [['superbalist.html','Fashion',['sneakers','shoes','nike'],20],['bags.source','Fashion',['bag'],25],['beauty.source','Beauty',['skincare'],18],['home.source','Home',['kitchen'],18]]){
 const items=[...read(file).matchAll(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)].map(m=>JSON.parse(m[1])).filter(x=>x['@type']==='ItemList').flatMap(x=>x.itemListElement.map(e=>e.item))
 if(file==='bags.source')items.sort((a,b)=>Number(/backpack/i.test(b.url))-Number(/backpack/i.test(a.url)))
 for(const p of items.slice(0,max))add(`SB-${p.sku}`,`${p.brand?.name||''} ${p.name}`.trim(),Number(p.offers.price),p.image,p.url,'Superbalist',category,[...tags,...(/backpack/i.test(p.url)?['backpack']:[])])
}
for(const [file,host,seller,category,tags] of [['books.source','exclusivebooks.co.za','Exclusive Books','Books',['book']],['electronics.source','computermania.co.za','Computer Mania','Electronics',['headphones','headset','audio']]]){
 for(const p of JSON.parse(read(file)).products){const v=p.variants.find(v=>v.available&&Number(v.price)>0);if(!v)continue;add(`${category==='Books'?'EB':'CM'}-${p.id}`,p.title,Number(v.price),p.images[0]?.src,`https://${host}/products/${p.handle}`,seller,category,tags)}
}
if(new Set(entries.map(e=>e.product.externalId)).size!==entries.length)throw Error('Duplicate products')
fs.writeFileSync(path.join(root,'Data/demo-catalog.json'),JSON.stringify(entries,null,2)+'\n')
fs.writeFileSync(path.join(root,'frontend/src/data/demoImages.json'),JSON.stringify(Object.fromEntries(entries.map(e=>[e.product.externalId,e.product.imageUrl])),null,2)+'\n')
fs.writeFileSync(path.join(root,'artifacts/retailer-catalog/downloads.json'),JSON.stringify(downloads,null,2))
console.log(`${entries.length} retailer products; ${entries.filter(e=>e.tags.includes('backpack')).length} backpacks`)
