param([int]$Port = 5260)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$runtimePath = Join-Path $projectRoot 'artifacts/demo-runtime'
$publishPath = Join-Path $projectRoot 'artifacts/team-demo'
$tunnelPath = Join-Path $projectRoot 'artifacts/tools/cloudflared.exe'
if (-not (Test-Path (Join-Path $publishPath 'wwwroot/index.html'))) { throw 'Build artifacts/team-demo and copy frontend/dist into its wwwroot first.' }
if (-not (Test-Path $tunnelPath)) { throw 'The verified Cloudflare tunnel executable is missing.' }
if ((Get-FileHash $tunnelPath -Algorithm SHA256).Hash -ne 'F096265EC2FCBE9BB6E2D64268DB167CED3FCBB83D894BDB9E2FCDB26F2EA7E2') {
    throw 'Unexpected Cloudflare executable. Verify its release checksum before updating this script.'
}
New-Item -ItemType Directory -Force $runtimePath | Out-Null
$statePath = Join-Path $runtimePath 'state.json'
if (Test-Path $statePath) {
    $previous = Get-Content -Raw $statePath | ConvertFrom-Json
    foreach ($item in @($previous.api, $previous.tunnel)) {
        $existing = Get-Process -Id $item.id -ErrorAction SilentlyContinue
        if ($existing -and $existing.StartTime.ToUniversalTime().ToString('o') -eq $item.started) {
            throw "The demo is already running at $($previous.url). Stop it with scripts/stop-team-demo.ps1 before restarting."
        }
    }
}
$runId = Get-Date -Format 'yyyyMMdd-HHmmss'
$tunnelError = Join-Path $runtimePath "$runId-tunnel.log"
$tunnel = Start-Process -FilePath $tunnelPath -ArgumentList @('tunnel','--no-autoupdate','--url',"http://127.0.0.1:$Port",'--protocol','http2') -WindowStyle Hidden -PassThru -RedirectStandardError $tunnelError -RedirectStandardOutput (Join-Path $runtimePath "$runId-tunnel.out")
$api = $null
try {
    $url = $null
    for ($attempt = 0; $attempt -lt 45; $attempt++) {
        if ($tunnel.HasExited) { throw "Tunnel exited. See $tunnelError" }
        if (Test-Path $tunnelError) {
            $logContent = Get-Content -Raw $tunnelError
            if (-not [string]::IsNullOrEmpty($logContent)) {
                $match = [regex]::Match($logContent, 'https://[a-z0-9-]+\.trycloudflare\.com')
                if ($match.Success) { $url = $match.Value; break }
            }
        }
        Start-Sleep -Seconds 1
        $tunnel.Refresh()
    }
    if (-not $url) { throw "No tunnel URL returned. See $tunnelError" }
    $settings = @{
        ASPNETCORE_ENVIRONMENT = 'Production'
        ASPNETCORE_URLS = "http://127.0.0.1:$Port"
        ConnectionStrings__DefaultConnection = 'Server=(localdb)\mssqllocaldb;Database=SmartShopTeamDemo;Trusted_Connection=True;TrustServerCertificate=True'
        Authentication__FrontendOrigin = $url
        Jwt__Key = [Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(48))
        SeedDemoUsers = 'false'
    }
    $previousEnvironment = @{}
    try {
        foreach ($name in $settings.Keys) {
            $previousEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
            [Environment]::SetEnvironmentVariable($name, $settings[$name], 'Process')
        }
        $api = Start-Process -FilePath 'dotnet' -ArgumentList @('SmartShop.Api.dll') -WorkingDirectory $publishPath -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runtimePath "$runId-api.log") -RedirectStandardError (Join-Path $runtimePath "$runId-api.err")
    } finally {
        foreach ($name in $settings.Keys) { [Environment]::SetEnvironmentVariable($name, $previousEnvironment[$name], 'Process') }
    }
    $healthy = $false
    for ($attempt = 0; $attempt -lt 45; $attempt++) {
        if ($api.HasExited) { throw "Demo API exited. See $runtimePath" }
        try {
            $health = Invoke-RestMethod "http://127.0.0.1:$Port/api/health" -TimeoutSec 2
            if ($health.status -eq 'ok') { $healthy = $true; break }
        } catch { Start-Sleep -Seconds 1 }
        $api.Refresh()
    }
    if (-not $healthy) { throw 'Demo API did not become healthy.' }
    @{
        url = $url
        port = $Port
        database = 'SmartShopTeamDemo'
        api = @{ id = $api.Id; started = $api.StartTime.ToUniversalTime().ToString('o') }
        tunnel = @{ id = $tunnel.Id; started = $tunnel.StartTime.ToUniversalTime().ToString('o') }
    } | ConvertTo-Json | Set-Content $statePath
    Write-Output "Demo URL: $url"
    Write-Output 'The app and tunnel run in the background. Keep this computer awake and online.'
} catch {
    if ($api -and -not $api.HasExited) { $api.Kill() }
    if (-not $tunnel.HasExited) { $tunnel.Kill() }
    throw
}
