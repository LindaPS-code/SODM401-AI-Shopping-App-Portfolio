namespace SmartShop.Api.DTOs;

public record RegisterRequest(string FirstName, string LastName, string Email, string Password);

public record LoginRequest(string Email, string Password);

public record AuthResponse(
    string Token,
    int UserId,
    string FirstName,
    string LastName,
    string Email);

public record SetBudgetRequest(decimal Amount);

public record BudgetResponse(
    int BudgetId,
    decimal Amount,
    decimal SpentAmount,
    decimal RemainingAmount,
    int PercentRemaining,
    DateOnly StartDate,
    DateOnly EndDate);

public record ProductDto(
    string ExternalId,
    string Name,
    string? ImageUrl,
    decimal Price,
    string Currency,
    string? Seller,
    string? Location,
    string? ProductUrl,
    decimal? ShippingCost,
    bool? WithinBudget);

public record ProductSearchResponse(
    string Source,
    decimal? RemainingBudget,
    IReadOnlyList<ProductDto> Products);

public record ProductDetailsDto(
    string ExternalId,
    string Name,
    string? ImageUrl,
    decimal Price,
    string Currency,
    string? Seller,
    string? Location,
    string? ProductUrl,
    decimal? ShippingCost,
    string? Condition,
    string? Description,
    bool? WithinBudget);

public record AddFavouriteRequest(
    string ExternalId,
    string Name,
    string? ImageUrl,
    decimal Price,
    string? Currency,
    string? Seller,
    string? Location,
    string? ProductUrl);

public record FavouriteResponse(
    int FavouriteId,
    string ExternalId,
    string Name,
    string? ImageUrl,
    decimal Price,
    string Currency,
    string? Seller,
    string? Location,
    string? ProductUrl,
    bool WithinBudget);

public record CheckoutItemRequest(
    string ExternalId,
    string Name,
    string? ImageUrl,
    decimal Price,
    int Quantity);

public record CheckoutRequest(
    IReadOnlyList<CheckoutItemRequest> Items,
    string ShippingAddress,
    decimal ShippingCost,
    string? PaymentMethod);

public record BudgetAlertDto(
    string Message,
    decimal ItemTotal,
    decimal RemainingBudget,
    decimal ShortBy);

public record CheckoutResponse(
    bool Allowed,
    BudgetAlertDto? Alert,
    IReadOnlyList<ProductDto>? SimilarItems,
    OrderResponse? Order);

public record OrderItemResponse(
    string ExternalId,
    string Name,
    string? ImageUrl,
    decimal Price,
    int Quantity);

public record OrderResponse(
    int OrderId,
    string OrderNumber,
    decimal Subtotal,
    decimal ShippingCost,
    decimal TotalAmount,
    string ShippingAddress,
    string PaymentMethod,
    string Status,
    DateTime CreatedAt,
    IReadOnlyList<OrderItemResponse> Items);

public record RecommendationResponse(
    string Source,
    decimal RemainingBudget,
    IReadOnlyList<string> Keywords,
    IReadOnlyList<ProductDto> Products);
