using System.Security.Claims;

namespace SmartShop.Api.Helpers;

public static class ClaimsPrincipalExtensions
{
    public static int GetUserId(this ClaimsPrincipal user)
    {
        var value = user.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? throw new InvalidOperationException("The login token is missing a user id.");

        return int.Parse(value);
    }
}
