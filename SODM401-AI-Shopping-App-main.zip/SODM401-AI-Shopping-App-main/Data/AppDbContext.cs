using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Models;

namespace SmartShop.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<User> Users => Set<User>();
    public DbSet<ExternalLogin> ExternalLogins => Set<ExternalLogin>();
    public DbSet<Budget> Budgets => Set<Budget>();
    public DbSet<Favourite> Favourites => Set<Favourite>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ExternalLogin>(entity =>
        {
            entity.HasKey(login => new { login.Provider, login.Subject });
            entity.Property(login => login.Provider).HasMaxLength(16);
            entity.Property(login => login.Subject).HasMaxLength(255);
            entity.HasOne(login => login.User).WithMany().HasForeignKey(login => login.UserId);
        });
        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(user => user.UserId);
            entity.Property(user => user.FirstName).HasMaxLength(100).IsRequired();
            entity.Property(user => user.LastName).HasMaxLength(100).IsRequired();
            entity.Property(user => user.Email).HasMaxLength(150).IsRequired();
            entity.HasIndex(user => user.Email).IsUnique();
            entity.Property(user => user.PasswordHash).HasMaxLength(255).IsRequired();
        });

        modelBuilder.Entity<Budget>(entity =>
        {
            entity.HasKey(budget => budget.BudgetId);
            entity.Property(budget => budget.Amount).HasColumnType("decimal(18,2)");
            entity.Property(budget => budget.SpentAmount).HasColumnType("decimal(18,2)");
            entity.Ignore(budget => budget.RemainingAmount);
            entity.Ignore(budget => budget.PercentRemaining);
            entity.HasOne(budget => budget.User)
                .WithMany(user => user.Budgets)
                .HasForeignKey(budget => budget.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Favourite>(entity =>
        {
            entity.HasKey(favourite => favourite.FavouriteId);
            entity.Property(favourite => favourite.ExternalId).HasMaxLength(100).IsRequired();
            entity.Property(favourite => favourite.Name).HasMaxLength(300).IsRequired();
            entity.Property(favourite => favourite.Price).HasColumnType("decimal(18,2)");
            entity.Property(favourite => favourite.Currency).HasMaxLength(10);
            entity.HasIndex(favourite => new { favourite.UserId, favourite.ExternalId }).IsUnique();
            entity.HasOne(favourite => favourite.User)
                .WithMany(user => user.Favourites)
                .HasForeignKey(favourite => favourite.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(order => order.OrderId);
            entity.Property(order => order.OrderNumber).HasMaxLength(20).IsRequired();
            entity.HasIndex(order => order.OrderNumber).IsUnique();
            entity.Property(order => order.Subtotal).HasColumnType("decimal(18,2)");
            entity.Property(order => order.ShippingCost).HasColumnType("decimal(18,2)");
            entity.Property(order => order.TotalAmount).HasColumnType("decimal(18,2)");
            entity.HasOne(order => order.User)
                .WithMany(user => user.Orders)
                .HasForeignKey(order => order.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<OrderItem>(entity =>
        {
            entity.HasKey(item => item.OrderItemId);
            entity.Property(item => item.Price).HasColumnType("decimal(18,2)");
            entity.HasOne(item => item.Order)
                .WithMany(order => order.Items)
                .HasForeignKey(item => item.OrderId)
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}

public static class DbSeeder
{
    public static void Seed(AppDbContext db)
    {
        if (db.Users.Any())
        {
            return;
        }

        var hasher = new PasswordHasher<User>();
        var createdAt = new DateTime(2026, 8, 1, 10, 0, 0, DateTimeKind.Utc);

        var sanele = CreateUser(hasher, "Sanele", "Dlamini", "sanele@student.ac.za", createdAt);
        var amahle = CreateUser(hasher, "Amahle", "Khumalo", "amahle@student.ac.za", createdAt);
        var thando = CreateUser(hasher, "Thando", "Mthembu", "thando@student.ac.za", createdAt);

        db.Users.AddRange(sanele, amahle, thando);
        db.SaveChanges();

        db.Budgets.AddRange(
            new Budget
            {
                UserId = sanele.UserId,
                Amount = 1500.00m,
                SpentAmount = 320.00m,
                StartDate = new DateOnly(2026, 8, 1),
                EndDate = new DateOnly(2026, 8, 31),
                CreatedAt = createdAt
            },
            new Budget
            {
                UserId = amahle.UserId,
                Amount = 2000.00m,
                SpentAmount = 450.00m,
                StartDate = new DateOnly(2026, 8, 1),
                EndDate = new DateOnly(2026, 8, 31),
                CreatedAt = createdAt
            },
            new Budget
            {
                UserId = thando.UserId,
                Amount = 1200.00m,
                SpentAmount = 180.00m,
                StartDate = new DateOnly(2026, 8, 1),
                EndDate = new DateOnly(2026, 8, 31),
                CreatedAt = createdAt
            });

        db.SaveChanges();
    }

    private static User CreateUser(PasswordHasher<User> hasher, string firstName, string lastName, string email, DateTime createdAt)
    {
        var user = new User
        {
            FirstName = firstName,
            LastName = lastName,
            Email = email,
            CreatedAt = createdAt
        };

        user.PasswordHash = hasher.HashPassword(user, "Password123!");
        return user;
    }
}
