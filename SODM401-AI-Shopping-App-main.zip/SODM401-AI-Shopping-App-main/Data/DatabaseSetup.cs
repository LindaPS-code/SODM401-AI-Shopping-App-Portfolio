using Microsoft.EntityFrameworkCore;

namespace SmartShop.Api.Data;

public static class DatabaseSetup
{
    public static async Task InitializeAsync(AppDbContext db)
    {
        await db.Database.EnsureCreatedAsync();
        // Add the provider mapping to existing MVP databases without replacing any user data.
        // New databases already receive this table through the EF model above.
        await db.Database.ExecuteSqlRawAsync("""
            IF OBJECT_ID(N'dbo.ExternalLogins', N'U') IS NULL
            BEGIN
                CREATE TABLE [dbo].[ExternalLogins] (
                    [Provider] nvarchar(16) NOT NULL,
                    [Subject] nvarchar(255) NOT NULL,
                    [UserId] int NOT NULL,
                    CONSTRAINT [PK_ExternalLogins] PRIMARY KEY ([Provider], [Subject]),
                    CONSTRAINT [FK_ExternalLogins_Users_UserId] FOREIGN KEY ([UserId])
                        REFERENCES [dbo].[Users] ([UserId]) ON DELETE CASCADE
                );
                CREATE INDEX [IX_ExternalLogins_UserId] ON [dbo].[ExternalLogins] ([UserId]);
            END
            """);
    }
}
