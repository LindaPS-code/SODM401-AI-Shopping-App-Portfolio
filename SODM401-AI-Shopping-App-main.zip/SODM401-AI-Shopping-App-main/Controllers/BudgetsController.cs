using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Data;
using SmartShop.Api.DTOs;
using SmartShop.Api.Helpers;
using SmartShop.Api.Models;
using SmartShop.Api.Services;

namespace SmartShop.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/budgets")]
public class BudgetsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly BudgetService _budgets;

    public BudgetsController(AppDbContext db, BudgetService budgets)
    {
        _db = db;
        _budgets = budgets;
    }

    [HttpGet("current")]
    public async Task<ActionResult<BudgetResponse>> GetCurrent(CancellationToken cancellationToken)
    {
        var budget = await _budgets.GetCurrentAsync(User.GetUserId(), cancellationToken);
        if (budget == null)
        {
            return NotFound(new { message = "No budget is set for this month yet." });
        }

        return Ok(BudgetService.ToResponse(budget));
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<BudgetResponse>>> History(CancellationToken cancellationToken)
    {
        var userId = User.GetUserId();
        var budgets = await _db.Budgets
            .Where(budget => budget.UserId == userId)
            .OrderByDescending(budget => budget.StartDate)
            .ToListAsync(cancellationToken);

        return Ok(budgets.Select(BudgetService.ToResponse).ToList());
    }

    [HttpPut("current")]
    public async Task<ActionResult<BudgetResponse>> SetCurrent([FromBody] SetBudgetRequest request, CancellationToken cancellationToken)
    {
        if (request.Amount <= 0)
        {
            return BadRequest(new { message = "Monthly budget must be greater than 0." });
        }

        var userId = User.GetUserId();
        var budget = await _budgets.GetCurrentAsync(userId, cancellationToken);
        if (budget == null)
        {
            var (start, end) = BudgetService.CurrentMonthRange();
            budget = new Budget
            {
                UserId = userId,
                Amount = request.Amount,
                SpentAmount = 0,
                StartDate = start,
                EndDate = end,
                CreatedAt = DateTime.UtcNow
            };
            _db.Budgets.Add(budget);
        }
        else
        {
            budget.Amount = request.Amount;
        }

        await _db.SaveChangesAsync(cancellationToken);
        return Ok(BudgetService.ToResponse(budget));
    }
}
