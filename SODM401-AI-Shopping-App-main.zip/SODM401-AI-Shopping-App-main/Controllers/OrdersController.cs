using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Data;
using SmartShop.Api.DTOs;
using SmartShop.Api.Helpers;
using SmartShop.Api.Models;
using SmartShop.Api.Services;

namespace SmartShop.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly BudgetService _budgets;
    private readonly EbayProductService _products;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(
        AppDbContext db,
        BudgetService budgets,
        EbayProductService products,
        ILogger<OrdersController> logger)
    {
        _db = db;
        _budgets = budgets;
        _products = products;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<OrderResponse>>> List(CancellationToken cancellationToken)
    {
        var userId = User.GetUserId();
        var orders = await _db.Orders
            .Include(order => order.Items)
            .Where(order => order.UserId == userId)
            .OrderByDescending(order => order.CreatedAt)
            .ToListAsync(cancellationToken);

        return Ok(orders.Select(ToResponse).ToList());
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<OrderResponse>> GetById(int id, CancellationToken cancellationToken)
    {
        var userId = User.GetUserId();
        var order = await _db.Orders
            .Include(item => item.Items)
            .FirstOrDefaultAsync(item => item.OrderId == id && item.UserId == userId, cancellationToken);

        if (order == null)
        {
            return NotFound(new { message = "Order was not found." });
        }

        return Ok(ToResponse(order));
    }

    [HttpPost("checkout")]
    public async Task<ActionResult<CheckoutResponse>> Checkout(
        [FromBody] CheckoutRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Items == null || request.Items.Count == 0)
        {
            return BadRequest(new { message = "Add at least one item before checkout." });
        }

        if (string.IsNullOrWhiteSpace(request.ShippingAddress))
        {
            return BadRequest(new { message = "Shipping address is required." });
        }

        if (request.Items.Count > 50 || request.Items.Any(item =>
            string.IsNullOrWhiteSpace(item.ExternalId) || item.Quantity < 1 || item.Quantity > 99))
        {
            return BadRequest(new { message = "Each cart item needs a valid product and a quantity from 1 to 99." });
        }

        // Resolve prices through the same provider as search; never trust browser totals.
        var verifiedItems = new List<CheckoutItemRequest>();
        decimal shipping = 0;
        foreach (var item in request.Items)
        {
            var product = await _products.GetDetailsAsync(item.ExternalId, cancellationToken);
            if (product == null || product.Price <= 0 || product.ShippingCost == null)
            {
                return BadRequest(new { message = "A product or its shipping price is unavailable. Please review the cart." });
            }
            if (product.Price != item.Price)
            {
                return Conflict(new { message = "A product price has changed. Remove it from your cart and add it again to review the new price." });
            }
            verifiedItems.Add(new CheckoutItemRequest(product.ExternalId, product.Name, product.ImageUrl, product.Price, item.Quantity));
            shipping += product.ShippingCost.Value * item.Quantity;
        }
        if (shipping != request.ShippingCost)
        {
            return Conflict(new { message = "Shipping prices have changed. Please refresh your cart before ordering." });
        }

        // Serialize budget reads and writes so simultaneous orders cannot overspend.
        await using var transaction = await _db.Database.BeginTransactionAsync(
            System.Data.IsolationLevel.Serializable, cancellationToken);

        var userId = User.GetUserId();
        var budget = await _budgets.GetCurrentAsync(userId, cancellationToken);
        if (budget == null)
        {
            return BadRequest(new { message = "Set a monthly budget before you check out." });
        }

        var subtotal = verifiedItems.Sum(item => item.Price * item.Quantity);
        var total = subtotal + shipping;

        if (total > budget.RemainingAmount)
        {
            var shortBy = total - budget.RemainingAmount;
            var searchTerm = request.Items[0].Name;
            var (source, similar) = await _products.SearchAsync(
                searchTerm,
                null,
                null,
                budget.RemainingAmount,
                null,
                null,
                null,
                null,
                8,
                cancellationToken);

            var withinBudget = similar
                .Where(product => product.Price <= budget.RemainingAmount)
                .Take(8)
                .ToList();

            _logger.LogInformation("Checkout blocked for user {UserId}. Short by {ShortBy}. Source {Source}.", userId, shortBy, source);

            return Ok(new CheckoutResponse(
                false,
                new BudgetAlertDto(
                    $"This purchase is over your remaining budget. Short by: R{shortBy:0.00}",
                    total,
                    budget.RemainingAmount,
                    shortBy),
                EbayProductService.MarkBudget(withinBudget, budget.RemainingAmount),
                null));
        }

        var order = new Order
        {
            OrderNumber = CreateOrderNumber(),
            UserId = userId,
            Subtotal = subtotal,
            ShippingCost = shipping,
            TotalAmount = total,
            ShippingAddress = request.ShippingAddress.Trim(),
            PaymentMethod = string.IsNullOrWhiteSpace(request.PaymentMethod) ? "Card" : request.PaymentMethod.Trim(),
            Status = "Confirmed",
            CreatedAt = DateTime.UtcNow,
            Items = verifiedItems.Select(item => new OrderItem
            {
                ExternalId = item.ExternalId,
                Name = item.Name,
                ImageUrl = item.ImageUrl,
                Price = item.Price,
                Quantity = Math.Max(item.Quantity, 1)
            }).ToList()
        };

        budget.SpentAmount += total;
        _db.Orders.Add(order);
        await _db.SaveChangesAsync(cancellationToken);
        await transaction.CommitAsync(cancellationToken);

        _logger.LogInformation(
            "Order {OrderNumber} confirmed for user {UserId}. Total R{Total}. Confirmation email would be sent here.",
            order.OrderNumber,
            userId,
            total);

        return Ok(new CheckoutResponse(true, null, null, ToResponse(order)));
    }

    private static string CreateOrderNumber()
    {
        return $"SS{Guid.NewGuid():N}"[..18];
    }

    private static OrderResponse ToResponse(Order order)
    {
        return new OrderResponse(
            order.OrderId,
            order.OrderNumber,
            order.Subtotal,
            order.ShippingCost,
            order.TotalAmount,
            order.ShippingAddress,
            order.PaymentMethod,
            order.Status,
            order.CreatedAt,
            order.Items.Select(item => new OrderItemResponse(
                item.ExternalId,
                item.Name,
                item.ImageUrl,
                item.Price,
                item.Quantity)).ToList());
    }
}
