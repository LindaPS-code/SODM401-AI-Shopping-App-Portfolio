using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Data;
using SmartShop.Api.DTOs;
using SmartShop.Api.Models;
using SmartShop.Api.Services;

namespace SmartShop.Api.Controllers;

[ApiController]
[Route("api/auth/external")]
public class ExternalAuthController(AppDbContext db, JwtTokenService tokens, ExternalCodeStore codes,
    IConfiguration configuration) : ControllerBase
{
    private const string ExchangeCookie = "__SmartShop.Exchange";

    [HttpGet("providers")]
    public IActionResult Providers() => Ok(ExternalAuthSetup.Providers.Select(provider => new
    {
        name = provider,
        enabled = ExternalAuthSetup.IsConfigured(configuration, provider),
        url = $"/api/auth/external/{provider.ToLowerInvariant()}/start"
    }));

    [HttpGet("{provider}/start")]
    public IActionResult Start(string provider)
    {
        var scheme = ExternalAuthSetup.Providers.FirstOrDefault(name => name.Equals(provider, StringComparison.OrdinalIgnoreCase));
        if (scheme == null || !ExternalAuthSetup.IsConfigured(configuration, scheme))
            return Redirect(ExternalAuthSetup.FrontendOrigin(configuration) + "/login?authError=not_configured");
        return Challenge(new AuthenticationProperties { RedirectUri = "/api/auth/external/complete" }, scheme);
    }

    [HttpGet("complete")]
    public async Task<IActionResult> Complete(CancellationToken cancellationToken)
    {
        var result = await HttpContext.AuthenticateAsync(ExternalAuthSetup.CookieScheme);
        await HttpContext.SignOutAsync(ExternalAuthSetup.CookieScheme);
        if (!result.Succeeded || result.Principal == null) return Failed("external_failed");
        var provider = result.Principal.FindFirstValue("smartshop_provider");
        var subject = result.Principal.FindFirstValue("sub");
        var email = result.Principal.FindFirstValue("email")?.Trim().ToLowerInvariant();
        if (provider == null || subject == null || email == null || email.Length > 150 || subject.Length > 255)
            return Failed("external_failed");

        var login = await db.ExternalLogins.Include(item => item.User)
            .SingleOrDefaultAsync(item => item.Provider == provider && item.Subject == subject, cancellationToken);
        User user;
        if (login != null) user = login.User;
        else
        {
            // Do not silently link an unverified local account merely because its email matches.
            if (await db.Users.AnyAsync(item => item.Email == email, cancellationToken)) return Failed("account_exists");
            var firstName = result.Principal.FindFirstValue("given_name") ?? email.Split('@')[0];
            var lastName = result.Principal.FindFirstValue("family_name") ?? "";
            user = new User { Email = email, FirstName = firstName[..Math.Min(firstName.Length, 100)],
                LastName = lastName[..Math.Min(lastName.Length, 100)], PasswordHash = "" };
            db.ExternalLogins.Add(new ExternalLogin { Provider = provider, Subject = subject, User = user });
            try { await db.SaveChangesAsync(cancellationToken); }
            catch (DbUpdateException) { return Failed("account_exists"); }
        }
        var handoff = codes.Create(user.UserId);
        Response.Cookies.Append(ExchangeCookie, handoff.BrowserSecret, new CookieOptions
        {
            HttpOnly = true, Secure = Request.IsHttps, SameSite = SameSiteMode.Lax,
            Path = "/api/auth/external/exchange", MaxAge = TimeSpan.FromMinutes(2), IsEssential = true
        });
        Response.Headers.CacheControl = "no-store";
        return Redirect(ExternalAuthSetup.FrontendOrigin(configuration) + "/auth/callback#code=" + handoff.Code);
    }

    public record ExchangeRequest(string Code);

    [HttpPost("exchange")]
    public async Task<IActionResult> Exchange(ExchangeRequest request, CancellationToken cancellationToken)
    {
        Response.Headers.CacheControl = "no-store";
        var browserSecret = Request.Cookies[ExchangeCookie];
        Response.Cookies.Delete(ExchangeCookie, new CookieOptions { Path = "/api/auth/external/exchange" });
        if (string.IsNullOrWhiteSpace(request.Code) || browserSecret == null)
            return Unauthorized(new { message = "Sign-in expired. Please try again." });
        var userId = codes.Consume(request.Code, browserSecret);
        var user = userId.HasValue ? await db.Users.FindAsync([userId.Value], cancellationToken) : null;
        if (user == null) return Unauthorized(new { message = "Sign-in expired. Please try again." });
        return Ok(new AuthResponse(tokens.CreateToken(user), user.UserId, user.FirstName, user.LastName, user.Email));
    }

    private IActionResult Failed(string code) => Redirect(ExternalAuthSetup.FrontendOrigin(configuration) + "/login?authError=" + code);
}
