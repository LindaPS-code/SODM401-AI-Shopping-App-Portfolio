using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Data;
using SmartShop.Api.DTOs;
using SmartShop.Api.Helpers;
using SmartShop.Api.Services;

namespace SmartShop.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/recommendations")]
public class RecommendationsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly BudgetService _budgets;
    private readonly OllamaService _ollama;
    private readonly EbayProductService _products;

    public RecommendationsController(
        AppDbContext db,
        BudgetService budgets,
        OllamaService ollama,
        EbayProductService products)
    {
        _db = db;
        _budgets = budgets;
        _ollama = ollama;
        _products = products;
    }

    [HttpGet]
    public async Task<ActionResult<RecommendationResponse>> Get([FromQuery] int limit = 8, CancellationToken cancellationToken = default)
    {
        var userId = User.GetUserId();
        var budget = await _budgets.GetCurrentAsync(userId, cancellationToken);
        if (budget == null)
        {
            return BadRequest(new { message = "Set a monthly budget to get recommendations." });
        }

        var liked = await _db.Favourites
            .Where(favourite => favourite.UserId == userId)
            .OrderByDescending(favourite => favourite.CreatedAt)
            .Select(favourite => favourite.Name)
            .Take(5)
            .ToListAsync(cancellationToken);

        var keywords = await _ollama.SuggestKeywordsAsync(budget.RemainingAmount, liked, cancellationToken);
        var products = new List<ProductDto>();
        string source = "demo";

        foreach (var keyword in keywords.Take(3))
        {
            var result = await _products.SearchAsync(
                keyword,
                null,
                null,
                budget.RemainingAmount,
                null,
                null,
                null,
                null,
                5,
                cancellationToken);

            source = result.Source;
            products.AddRange(result.Products);
        }

        var unique = products
            .GroupBy(product => product.ExternalId)
            .Select(group => group.First())
            .Where(product => product.Price <= budget.RemainingAmount)
            .Take(Math.Clamp(limit, 1, 20))
            .ToList();

        return Ok(new RecommendationResponse(
            source,
            budget.RemainingAmount,
            keywords,
            EbayProductService.MarkBudget(unique, budget.RemainingAmount)));
    }
}
