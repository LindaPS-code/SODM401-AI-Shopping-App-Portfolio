using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Data;
using SmartShop.Api.DTOs;
using SmartShop.Api.Helpers;
using SmartShop.Api.Models;
using SmartShop.Api.Services;

namespace SmartShop.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/favourites")]
public class FavouritesController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly BudgetService _budgets;

    public FavouritesController(AppDbContext db, BudgetService budgets)
    {
        _db = db;
        _budgets = budgets;
    }

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<FavouriteResponse>>> List(CancellationToken cancellationToken)
    {
        var userId = User.GetUserId();
        var remaining = (await _budgets.GetCurrentAsync(userId, cancellationToken))?.RemainingAmount ?? 0;
        var favourites = await _db.Favourites
            .Where(favourite => favourite.UserId == userId)
            .OrderByDescending(favourite => favourite.CreatedAt)
            .ToListAsync(cancellationToken);

        return Ok(favourites.Select(favourite => ToResponse(favourite, remaining)).ToList());
    }

    [HttpPost]
    public async Task<ActionResult<FavouriteResponse>> Add([FromBody] AddFavouriteRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.ExternalId) || string.IsNullOrWhiteSpace(request.Name))
        {
            return BadRequest(new { message = "externalId and name are required." });
        }

        var userId = User.GetUserId();
        var existing = await _db.Favourites.FirstOrDefaultAsync(
            favourite => favourite.UserId == userId && favourite.ExternalId == request.ExternalId,
            cancellationToken);

        if (existing != null)
        {
            var remainingExisting = (await _budgets.GetCurrentAsync(userId, cancellationToken))?.RemainingAmount ?? 0;
            return Ok(ToResponse(existing, remainingExisting));
        }

        var favourite = new Favourite
        {
            UserId = userId,
            ExternalId = request.ExternalId,
            Name = request.Name,
            ImageUrl = request.ImageUrl,
            Price = request.Price,
            Currency = string.IsNullOrWhiteSpace(request.Currency) ? "ZAR" : request.Currency,
            Seller = request.Seller,
            Location = request.Location,
            ProductUrl = request.ProductUrl,
            CreatedAt = DateTime.UtcNow
        };

        _db.Favourites.Add(favourite);
        await _db.SaveChangesAsync(cancellationToken);

        var remaining = (await _budgets.GetCurrentAsync(userId, cancellationToken))?.RemainingAmount ?? 0;
        return Ok(ToResponse(favourite, remaining));
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Remove(int id, CancellationToken cancellationToken)
    {
        var userId = User.GetUserId();
        var favourite = await _db.Favourites.FirstOrDefaultAsync(
            item => item.FavouriteId == id && item.UserId == userId,
            cancellationToken);

        if (favourite == null)
        {
            return NotFound(new { message = "Favourite was not found." });
        }

        _db.Favourites.Remove(favourite);
        await _db.SaveChangesAsync(cancellationToken);
        return NoContent();
    }

    private static FavouriteResponse ToResponse(Favourite favourite, decimal remaining)
    {
        return new FavouriteResponse(
            favourite.FavouriteId,
            favourite.ExternalId,
            favourite.Name,
            favourite.ImageUrl,
            favourite.Price,
            favourite.Currency,
            favourite.Seller,
            favourite.Location,
            favourite.ProductUrl,
            favourite.Price <= remaining);
    }
}
