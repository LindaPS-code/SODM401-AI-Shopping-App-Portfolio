using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SmartShop.Api.DTOs;
using SmartShop.Api.Helpers;
using SmartShop.Api.Services;

namespace SmartShop.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/products")]
public class ProductsController : ControllerBase
{
    private readonly EbayProductService _products;
    private readonly BudgetService _budgets;

    public ProductsController(EbayProductService products, BudgetService budgets)
    {
        _products = products;
        _budgets = budgets;
    }

    [HttpGet("categories")]
    [AllowAnonymous]
    public ActionResult<IReadOnlyList<object>> Categories()
    {
        return Ok(new[]
        {
            new { name = "Electronics", keyword = "headphones" },
            new { name = "Fashion", keyword = "sneakers" },
            new { name = "Home", keyword = "desk lamp" },
            new { name = "Beauty", keyword = "skincare" },
            new { name = "Books", keyword = "textbook" }
        });
    }

    [HttpGet("popular-searches")]
    [AllowAnonymous]
    public ActionResult<IReadOnlyList<string>> PopularSearches()
    {
        return Ok(new[] { "Sneakers", "Backpack", "Headphones", "Laptop stand", "Water bottle" });
    }

    [HttpGet("search")]
    public async Task<ActionResult<ProductSearchResponse>> Search(
        [FromQuery] string? q,
        [FromQuery] string? category,
        [FromQuery] decimal? minPrice,
        [FromQuery] decimal? maxPrice,
        [FromQuery] string? shipping,
        [FromQuery] string? location,
        [FromQuery] string? color,
        [FromQuery] string? size,
        [FromQuery] int limit = 20,
        CancellationToken cancellationToken = default)
    {
        var remaining = await GetRemainingAsync(cancellationToken);
        var (source, products) = await _products.SearchAsync(
            q, category, minPrice, maxPrice, shipping, location, color, size, limit, cancellationToken);

        return Ok(new ProductSearchResponse(
            source,
            remaining,
            EbayProductService.MarkBudget(products, remaining)));
    }

    [HttpGet("compare")]
    public async Task<ActionResult<ProductSearchResponse>> Compare(
        [FromQuery] string q,
        [FromQuery] int limit = 10,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(q))
        {
            return BadRequest(new { message = "Add a product name to compare prices, for example Nike Air Force 1." });
        }

        var remaining = await GetRemainingAsync(cancellationToken);
        var (source, products) = await _products.SearchAsync(
            q, null, null, null, null, null, null, null, limit, cancellationToken);

        var cheapestFirst = products.OrderBy(product => product.Price).ToList();
        return Ok(new ProductSearchResponse(
            source,
            remaining,
            EbayProductService.MarkBudget(cheapestFirst, remaining)));
    }

    [HttpGet("details")]
    public async Task<ActionResult<ProductDetailsDto>> Details(
        [FromQuery] string externalId,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(externalId))
        {
            return BadRequest(new { message = "externalId is required." });
        }

        var remaining = await GetRemainingAsync(cancellationToken);
        var product = await _products.GetDetailsAsync(externalId, cancellationToken);
        if (product == null)
        {
            return NotFound(new { message = "Product was not found." });
        }

        var marked = product with
        {
            WithinBudget = remaining.HasValue && product.Price <= remaining.Value
        };

        return Ok(marked);
    }

    private async Task<decimal?> GetRemainingAsync(CancellationToken cancellationToken)
    {
        var budget = await _budgets.GetCurrentAsync(User.GetUserId(), cancellationToken);
        return budget?.RemainingAmount;
    }
}
