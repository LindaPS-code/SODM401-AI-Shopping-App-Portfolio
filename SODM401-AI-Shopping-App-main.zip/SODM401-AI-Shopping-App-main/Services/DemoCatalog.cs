using System.Text.Json;
using System.Text.RegularExpressions;
using SmartShop.Api.DTOs;

namespace SmartShop.Api.Services;

public static class DemoCatalog
{
    private sealed record Entry(ProductDto Product, string Category, string[] Tags, string[] Colours, string[] Sizes, string Description);
    private static readonly IReadOnlyList<Entry> Entries = Load();
    public static IReadOnlyList<ProductDto> All { get; } = Entries.Select(entry => entry.Product).ToList();

    private static IReadOnlyList<Entry> Load()
    {
        using var stream = typeof(DemoCatalog).Assembly.GetManifestResourceStream("SmartShop.DemoCatalog.json")
            ?? throw new InvalidOperationException("The demo catalogue is missing.");
        return JsonSerializer.Deserialize<List<Entry>>(stream, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })!;
    }

    private static string Normalize(string word) => word.ToLowerInvariant() switch
    {
        "sneaker" or "sneakers" or "shoes" or "trainers" or "trainer" => "shoe",
        "headphones" or "earphones" or "earbuds" => "headphone",
        "backpacks" => "backpack",
        "textbooks" or "textbook" or "books" => "book",
        "laptops" => "laptop",
        "bottles" => "bottle",
        "grey" => "gray",
        var value => value
    };
    private static string[] Tokens(string text) => Regex.Matches(text.ToLowerInvariant(), @"[\p{L}\p{N}]+")
        .Select(match => Normalize(match.Value)).ToArray();

    public static string? Description(string id) => Entries.FirstOrDefault(entry => entry.Product.ExternalId == id)?.Description;

    public static IReadOnlyList<ProductDto> Search(string? query, decimal? minPrice, decimal? maxPrice,
        string? shipping, string? location, string? color, string? size, string? category = null)
    {
        IEnumerable<Entry> entries = Entries;
        if (!string.IsNullOrWhiteSpace(category)) entries = entries.Where(entry => entry.Category.Equals(category, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(query))
        {
            var terms = Tokens(query);
            entries = entries.Where(entry => {
                var words = Tokens(string.Join(' ', new[] { entry.Product.Name, entry.Product.Seller ?? "", entry.Category }
                    .Concat(entry.Tags).Concat(entry.Colours))).ToHashSet();
                return terms.All(words.Contains);
            });
        }
        if (!string.IsNullOrWhiteSpace(color)) entries = entries.Where(entry => entry.Colours.Any(value => Normalize(value) == Normalize(color)));
        if (!string.IsNullOrWhiteSpace(size)) entries = entries.Where(entry => entry.Sizes.Contains(size, StringComparer.OrdinalIgnoreCase));
        IEnumerable<ProductDto> items = entries.Select(entry => entry.Product);
        if (minPrice.HasValue) items = items.Where(product => product.Price >= minPrice);
        if (maxPrice.HasValue) items = items.Where(product => product.Price <= maxPrice);
        if (string.Equals(shipping, "free", StringComparison.OrdinalIgnoreCase)) items = items.Where(product => product.ShippingCost == 0);
        else if (string.Equals(shipping, "under50", StringComparison.OrdinalIgnoreCase)) items = items.Where(product => product.ShippingCost <= 50);
        else if (string.Equals(shipping, "under100", StringComparison.OrdinalIgnoreCase)) items = items.Where(product => product.ShippingCost <= 100);
        if (!string.IsNullOrWhiteSpace(location)) items = items.Where(product => product.Location?.Contains(location, StringComparison.OrdinalIgnoreCase) == true);
        return items.ToList();
    }
}
