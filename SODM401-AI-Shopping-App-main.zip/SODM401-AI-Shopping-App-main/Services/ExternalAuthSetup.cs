using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;

namespace SmartShop.Api.Services;

public static class ExternalAuthSetup
{
    public const string CookieScheme = "External";
    public static readonly string[] Providers = ["Google", "Apple"];

    public static bool IsConfigured(IConfiguration configuration, string provider) =>
        Providers.Contains(provider) &&
        !string.IsNullOrWhiteSpace(configuration[$"Authentication:{provider}:ClientId"]) &&
        !string.IsNullOrWhiteSpace(configuration[$"Authentication:{provider}:ClientSecret"]);

    public static string FrontendOrigin(IConfiguration configuration) =>
        (configuration["Authentication:FrontendOrigin"] ?? "http://localhost:5173").TrimEnd('/');

    public static void AddProviders(AuthenticationBuilder authentication, IConfiguration configuration)
    {
        authentication.AddCookie(CookieScheme, options =>
        {
            options.Cookie.Name = "__SmartShop.External";
            options.ExpireTimeSpan = TimeSpan.FromMinutes(5);
            options.Cookie.HttpOnly = true;
            options.Cookie.SameSite = SameSiteMode.Lax;
        });

        foreach (var provider in Providers.Where(provider => IsConfigured(configuration, provider)))
        {
            authentication.AddOpenIdConnect(provider, options =>
            {
                options.SignInScheme = CookieScheme;
                options.Authority = provider == "Google" ? "https://accounts.google.com" : "https://appleid.apple.com";
                options.ClientId = configuration[$"Authentication:{provider}:ClientId"]!;
                options.ClientSecret = configuration[$"Authentication:{provider}:ClientSecret"]!;
                options.CallbackPath = $"/api/auth/callback/{provider.ToLowerInvariant()}";
                options.ResponseType = "code";
                options.ResponseMode = provider == "Apple" ? "form_post" : "query";
                // Apple does not advertise PKCE support in its discovery metadata.
                options.UsePkce = provider == "Google";
                options.MapInboundClaims = false;
                options.SaveTokens = false;
                options.Scope.Clear();
                options.Scope.Add("openid");
                options.Scope.Add("email");
                if (provider == "Google") options.Scope.Add("profile");
                if (provider == "Google")
                {
                    options.NonceCookie.SameSite = SameSiteMode.Lax;
                    options.CorrelationCookie.SameSite = SameSiteMode.Lax;
                }
                options.Events = new OpenIdConnectEvents
                {
                    OnTokenValidated = context =>
                    {
                        var principal = context.Principal!;
                        if (string.IsNullOrEmpty(principal.FindFirstValue("sub")) ||
                            !string.Equals(principal.FindFirstValue("email_verified"), "true", StringComparison.OrdinalIgnoreCase) ||
                            string.IsNullOrWhiteSpace(principal.FindFirstValue("email")))
                        {
                            context.Fail("A verified email address is required.");
                        }
                        else ((ClaimsIdentity)principal.Identity!).AddClaim(new Claim("smartshop_provider", provider));
                        return Task.CompletedTask;
                    },
                    OnRemoteFailure = context =>
                    {
                        context.HandleResponse();
                        context.Response.Redirect(FrontendOrigin(configuration) + "/login?authError=external_failed");
                        return Task.CompletedTask;
                    }
                };
            });
        }
    }
}
