using System.Net.Http.Headers;
using System.Text.Json;
using Microsoft.Extensions.Options;
using SmartShop.Api.DTOs;
using SmartShop.Api.Options;

namespace SmartShop.Api.Services;

public class EbayProductService
{
    private static readonly Dictionary<string, string> CategoryKeywords = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Electronics"] = "headphones",
        ["Fashion"] = "sneakers",
        ["Home"] = "desk lamp",
        ["Beauty"] = "skincare",
        ["Books"] = "textbook"
    };

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly EbayAuthService _authService;
    private readonly EbayOptions _options;
    private readonly ILogger<EbayProductService> _logger;

    public EbayProductService(
        IHttpClientFactory httpClientFactory,
        EbayAuthService authService,
        IOptions<EbayOptions> options,
        ILogger<EbayProductService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _authService = authService;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<(string Source, IReadOnlyList<ProductDto> Products)> SearchAsync(
        string? query,
        string? category,
        decimal? minPriceZar,
        decimal? maxPriceZar,
        string? shipping,
        string? location,
        string? color,
        string? size,
        int limit,
        CancellationToken cancellationToken)
    {
        var keyword = BuildKeyword(query, category, color, size);

        var token = await _authService.GetAccessTokenAsync(cancellationToken);

        if (token == null)
        {
            _logger.LogInformation("Using demo products because eBay credentials or token are not available.");
            return ("demo", DemoCatalog.Search(query, minPriceZar, maxPriceZar, shipping, location, color, size, category).Take(Math.Clamp(limit, 1, 50)).ToList());
        }

        try
        {
            var client = _httpClientFactory.CreateClient("ebay");
            var url = BuildSearchUrl(keyword, minPriceZar, maxPriceZar, Math.Clamp(limit, 1, 50));
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            request.Headers.TryAddWithoutValidation("X-EBAY-C-MARKETPLACE-ID", _options.MarketplaceId);

            using var response = await client.SendAsync(request, cancellationToken);
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("eBay search failed ({Status}): {Body}", response.StatusCode, body);
                return ("demo", DemoCatalog.Search(query, minPriceZar, maxPriceZar, shipping, location, color, size, category).Take(Math.Clamp(limit, 1, 50)).ToList());
            }

            var products = ApplyLocalFilters(MapSearchResults(body), shipping, location);
            return ("ebay", products);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "eBay search threw an exception. Falling back to demo products.");
            return ("demo", DemoCatalog.Search(query, minPriceZar, maxPriceZar, shipping, location, color, size, category).Take(Math.Clamp(limit, 1, 50)).ToList());
        }
    }

    public async Task<ProductDetailsDto?> GetDetailsAsync(string externalId, CancellationToken cancellationToken)
    {
        var demo = DemoCatalog.All.FirstOrDefault(product =>
            product.ExternalId.Equals(externalId, StringComparison.OrdinalIgnoreCase));

        var token = await _authService.GetAccessTokenAsync(cancellationToken);
        if (token == null || externalId.StartsWith("DEMO-", StringComparison.OrdinalIgnoreCase))
        {
            return demo == null ? null : ToDetails(demo, DemoCatalog.Description(externalId));
        }

        try
        {
            var client = _httpClientFactory.CreateClient("ebay");
            var encodedId = Uri.EscapeDataString(externalId);
            using var request = new HttpRequestMessage(
                HttpMethod.Get,
                $"{_authService.ApiBaseUrl}/buy/browse/v1/item/{encodedId}");
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            request.Headers.TryAddWithoutValidation("X-EBAY-C-MARKETPLACE-ID", _options.MarketplaceId);

            using var response = await client.SendAsync(request, cancellationToken);
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                return demo == null ? null : ToDetails(demo, null);
            }

            using var json = JsonDocument.Parse(body);
            var item = json.RootElement;
            var mapped = MapItem(item);
            if (mapped == null)
            {
                return null;
            }

            var description = item.TryGetProperty("shortDescription", out var shortDescription)
                ? shortDescription.GetString()
                : item.TryGetProperty("description", out var descriptionNode)
                    ? TrimHtml(descriptionNode.GetString())
                    : null;

            var condition = item.TryGetProperty("condition", out var conditionNode)
                ? conditionNode.GetString()
                : null;

            return new ProductDetailsDto(
                mapped.ExternalId,
                mapped.Name,
                mapped.ImageUrl,
                mapped.Price,
                mapped.Currency,
                mapped.Seller,
                mapped.Location,
                mapped.ProductUrl,
                mapped.ShippingCost,
                condition,
                description,
                mapped.WithinBudget);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "eBay item details failed for {ItemId}.", externalId);
            return demo == null ? null : ToDetails(demo, null);
        }
    }

    public static IReadOnlyList<ProductDto> MarkBudget(IEnumerable<ProductDto> products, decimal? remainingBudget)
    {
        return products
            .Select(product => product with
            {
                WithinBudget = remainingBudget.HasValue && product.Price <= remainingBudget.Value
            })
            .ToList();
    }

    public static string BuildKeyword(string? query, string? category, string? color, string? size)
    {
        var parts = new List<string>();

        if (!string.IsNullOrWhiteSpace(query))
        {
            parts.Add(query.Trim());
        }
        else if (!string.IsNullOrWhiteSpace(category) && CategoryKeywords.TryGetValue(category, out var mapped))
        {
            parts.Add(mapped);
        }
        else if (!string.IsNullOrWhiteSpace(category))
        {
            parts.Add(category.Trim());
        }

        if (!string.IsNullOrWhiteSpace(color))
        {
            parts.Add(color.Trim());
        }

        if (!string.IsNullOrWhiteSpace(size))
        {
            parts.Add(size.Trim());
        }

        return parts.Count == 0 ? "sneakers" : string.Join(' ', parts);
    }

    private string BuildSearchUrl(string keyword, decimal? minPriceZar, decimal? maxPriceZar, int limit)
    {
        var parts = new List<string>
        {
            $"q={Uri.EscapeDataString(keyword)}",
            $"limit={limit}"
        };

        var minUsd = ToUsd(minPriceZar);
        var maxUsd = ToUsd(maxPriceZar);
        if (minUsd.HasValue || maxUsd.HasValue)
        {
            var min = minUsd.HasValue ? minUsd.Value.ToString("0.00") : string.Empty;
            var max = maxUsd.HasValue ? maxUsd.Value.ToString("0.00") : string.Empty;
            parts.Add($"filter={Uri.EscapeDataString($"price:[{min}..{max}],priceCurrency:USD")}");
        }

        return $"{_authService.ApiBaseUrl}/buy/browse/v1/item_summary/search?{string.Join('&', parts)}";
    }

    private List<ProductDto> MapSearchResults(string body)
    {
        using var json = JsonDocument.Parse(body);
        if (!json.RootElement.TryGetProperty("itemSummaries", out var summaries) ||
            summaries.ValueKind != JsonValueKind.Array)
        {
            return [];
        }

        var products = new List<ProductDto>();
        foreach (var item in summaries.EnumerateArray())
        {
            var mapped = MapItem(item);
            if (mapped != null)
            {
                products.Add(mapped);
            }
        }

        return products;
    }

    private ProductDto? MapItem(JsonElement item)
    {
        var id = ReadString(item, "itemId");
        var name = ReadString(item, "title");
        if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(name))
        {
            return null;
        }

        decimal? usd = null;
        if (item.TryGetProperty("price", out var priceNode) &&
            priceNode.TryGetProperty("value", out var valueNode) &&
            decimal.TryParse(valueNode.GetString(), out var parsed))
        {
            usd = parsed;
        }

        var imageUrl = item.TryGetProperty("image", out var image) && image.TryGetProperty("imageUrl", out var imageUrlNode)
            ? imageUrlNode.GetString()
            : null;

        var seller = item.TryGetProperty("seller", out var sellerNode)
            ? ReadString(sellerNode, "username")
            : null;

        string? location = null;
        if (item.TryGetProperty("itemLocation", out var locationNode))
        {
            var city = ReadString(locationNode, "city");
            var country = ReadString(locationNode, "country");
            location = string.Join(", ", new[] { city, country }.Where(part => !string.IsNullOrWhiteSpace(part)));
        }

        decimal? shippingCost = null;
        if (item.TryGetProperty("shippingOptions", out var shipping) &&
            shipping.ValueKind == JsonValueKind.Array &&
            shipping.GetArrayLength() > 0)
        {
            var first = shipping[0];
            if (first.TryGetProperty("shippingCost", out var shippingCostNode) &&
                shippingCostNode.TryGetProperty("value", out var shippingValue) &&
                decimal.TryParse(shippingValue.GetString(), out var shippingUsd))
            {
                shippingCost = ToZar(shippingUsd);
            }
        }

        var productUrl = ReadString(item, "itemWebUrl");

        return new ProductDto(
            id,
            name,
            imageUrl,
            ToZar(usd ?? 0),
            "ZAR",
            seller,
            string.IsNullOrWhiteSpace(location) ? null : location,
            productUrl,
            shippingCost,
            null);
    }

    private static IReadOnlyList<ProductDto> ApplyLocalFilters(
        IReadOnlyList<ProductDto> products,
        string? shipping,
        string? location)
    {
        IEnumerable<ProductDto> filtered = products;

        if (string.Equals(shipping, "free", StringComparison.OrdinalIgnoreCase))
        {
            filtered = filtered.Where(product => product.ShippingCost == 0);
        }
        else if (string.Equals(shipping, "under50", StringComparison.OrdinalIgnoreCase))
        {
            filtered = filtered.Where(product => product.ShippingCost.HasValue && product.ShippingCost.Value <= 50);
        }
        else if (string.Equals(shipping, "under100", StringComparison.OrdinalIgnoreCase))
        {
            filtered = filtered.Where(product => product.ShippingCost.HasValue && product.ShippingCost.Value <= 100);
        }

        if (!string.IsNullOrWhiteSpace(location))
        {
            filtered = filtered.Where(product =>
                product.Location?.Contains(location, StringComparison.OrdinalIgnoreCase) == true);
        }

        return filtered.ToList();
    }

    private decimal ToZar(decimal usd) => Math.Round(usd * _options.ZarPerUsd, 2);

    private decimal? ToUsd(decimal? zar)
    {
        if (!zar.HasValue)
        {
            return null;
        }

        if (_options.ZarPerUsd <= 0)
        {
            return zar;
        }

        return Math.Round(zar.Value / _options.ZarPerUsd, 2);
    }

    private static ProductDetailsDto ToDetails(ProductDto product, string? description)
    {
        return new ProductDetailsDto(
            product.ExternalId,
            product.Name,
            product.ImageUrl,
            product.Price,
            product.Currency,
            product.Seller,
            product.Location,
            product.ProductUrl,
            product.ShippingCost,
            "New",
            description,
            product.WithinBudget);
    }

    private static string? ReadString(JsonElement element, string name)
    {
        return element.TryGetProperty(name, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;
    }

    private static string? TrimHtml(string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            return value;
        }

        var stripped = System.Text.RegularExpressions.Regex.Replace(value, "<.*?>", " ");
        stripped = System.Text.RegularExpressions.Regex.Replace(stripped, @"\s+", " ").Trim();
        return stripped.Length <= 400 ? stripped : stripped[..400] + "...";
    }
}
