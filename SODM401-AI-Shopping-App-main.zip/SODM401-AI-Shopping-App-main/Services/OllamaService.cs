using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Options;
using SmartShop.Api.Options;

namespace SmartShop.Api.Services;

public class OllamaService
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly OllamaOptions _options;
    private readonly ILogger<OllamaService> _logger;

    public OllamaService(
        IHttpClientFactory httpClientFactory,
        IOptions<OllamaOptions> options,
        ILogger<OllamaService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<IReadOnlyList<string>> SuggestKeywordsAsync(
        decimal remainingBudget,
        IReadOnlyList<string> likedItems,
        CancellationToken cancellationToken)
    {
        var fallback = FallbackKeywords(remainingBudget, likedItems);

        try
        {
            var client = _httpClientFactory.CreateClient("ollama");
            var prompt =
                """
                You are SmartShop, a shopping assistant for South African students.
                Suggest 5 short product search keywords the student can afford.
                Reply with JSON only in this shape: {"keywords":["backpack","headphones"]}
                """ +
                $" Remaining budget: R{remainingBudget:0.00}." +
                (likedItems.Count == 0
                    ? " Liked items: none yet."
                    : $" Liked items: {string.Join(", ", likedItems)}.");

            var payload = new
            {
                model = _options.Model,
                prompt,
                stream = false,
                format = "json"
            };

            using var content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");
            using var response = await client.PostAsync(
                $"{_options.BaseUrl.TrimEnd('/')}/api/generate",
                content,
                cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogInformation("Ollama is not available ({Status}). Using fallback keywords.", response.StatusCode);
                return fallback;
            }

            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            using var json = JsonDocument.Parse(body);
            var text = json.RootElement.TryGetProperty("response", out var responseNode)
                ? responseNode.GetString()
                : body;

            var keywords = ParseKeywords(text);
            return keywords.Count == 0 ? fallback : keywords;
        }
        catch (Exception ex)
        {
            _logger.LogInformation(ex, "Ollama call failed. Using fallback keywords.");
            return fallback;
        }
    }

    public static IReadOnlyList<string> FallbackKeywords(decimal remainingBudget, IReadOnlyList<string> likedItems)
    {
        if (likedItems.Count > 0)
        {
            return likedItems.Take(5).ToList();
        }

        if (remainingBudget < 200)
        {
            return ["notebook", "pen set", "usb cable", "phone case", "socks"];
        }

        if (remainingBudget < 800)
        {
            return ["backpack", "headphones", "water bottle", "desk lamp", "sneakers"];
        }

        return ["sneakers", "bluetooth speaker", "hoodie", "laptop stand", "backpack"];
    }

    private static List<string> ParseKeywords(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return [];
        }

        try
        {
            using var json = JsonDocument.Parse(text);
            if (json.RootElement.TryGetProperty("keywords", out var keywords) &&
                keywords.ValueKind == JsonValueKind.Array)
            {
                return keywords.EnumerateArray()
                    .Select(item => item.GetString())
                    .Where(item => !string.IsNullOrWhiteSpace(item))
                    .Select(item => item!.Trim())
                    .Take(5)
                    .ToList();
            }
        }
        catch (JsonException)
        {
            var match = Regex.Match(text, "\\[.*\\]", RegexOptions.Singleline);
            if (match.Success)
            {
                try
                {
                    var values = JsonSerializer.Deserialize<List<string>>(match.Value);
                    return values?.Where(item => !string.IsNullOrWhiteSpace(item)).Take(5).ToList() ?? [];
                }
                catch (JsonException)
                {
                    return [];
                }
            }
        }

        return [];
    }
}
