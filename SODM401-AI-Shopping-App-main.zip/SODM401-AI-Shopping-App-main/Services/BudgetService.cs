using Microsoft.EntityFrameworkCore;
using SmartShop.Api.Data;
using SmartShop.Api.DTOs;
using SmartShop.Api.Models;

namespace SmartShop.Api.Services;

public class BudgetService
{
    private readonly AppDbContext _db;

    public BudgetService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<Budget?> GetCurrentAsync(int userId, CancellationToken cancellationToken = default)
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);

        return await _db.Budgets
            .Where(budget => budget.UserId == userId && budget.StartDate <= today && budget.EndDate >= today)
            .OrderByDescending(budget => budget.CreatedAt)
            .FirstOrDefaultAsync(cancellationToken);
    }

    public static BudgetResponse ToResponse(Budget budget)
    {
        return new BudgetResponse(
            budget.BudgetId,
            budget.Amount,
            budget.SpentAmount,
            budget.RemainingAmount,
            budget.PercentRemaining,
            budget.StartDate,
            budget.EndDate);
    }

    public static (DateOnly Start, DateOnly End) CurrentMonthRange()
    {
        var today = DateOnly.FromDateTime(DateTime.UtcNow);
        var start = new DateOnly(today.Year, today.Month, 1);
        var end = start.AddMonths(1).AddDays(-1);
        return (start, end);
    }
}
