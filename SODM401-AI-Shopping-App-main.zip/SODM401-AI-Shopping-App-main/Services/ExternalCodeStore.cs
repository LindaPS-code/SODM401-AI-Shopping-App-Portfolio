using System.Collections.Concurrent;
using System.Security.Cryptography;

namespace SmartShop.Api.Services;

// A short-lived, single-use handoff keeps the app JWT out of redirect URLs.
public class ExternalCodeStore
{
    private record Entry(int UserId, string BrowserSecret, DateTime Expires);
    private readonly ConcurrentDictionary<string, Entry> _entries = new();

    public (string Code, string BrowserSecret) Create(int userId)
    {
        foreach (var entry in _entries.Where(entry => entry.Value.Expires < DateTime.UtcNow))
            _entries.TryRemove(entry.Key, out _);
        var code = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        var browserSecret = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        _entries[code] = new Entry(userId, browserSecret, DateTime.UtcNow.AddMinutes(2));
        return (code, browserSecret);
    }

    public int? Consume(string code, string browserSecret)
    {
        if (!_entries.TryRemove(code, out var entry) || entry.Expires < DateTime.UtcNow ||
            !CryptographicOperations.FixedTimeEquals(System.Text.Encoding.UTF8.GetBytes(entry.BrowserSecret),
                System.Text.Encoding.UTF8.GetBytes(browserSecret))) return null;
        return entry.UserId;
    }
}
