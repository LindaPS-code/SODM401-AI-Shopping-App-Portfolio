using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using SmartShop.Api.Options;

namespace SmartShop.Api.Services;

public class EbayAuthService
{
    private const string CacheKey = "ebay-access-token";
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IMemoryCache _cache;
    private readonly EbayOptions _options;
    private readonly ILogger<EbayAuthService> _logger;
    private readonly SemaphoreSlim _gate = new(1, 1);

    public EbayAuthService(
        IHttpClientFactory httpClientFactory,
        IMemoryCache cache,
        IOptions<EbayOptions> options,
        ILogger<EbayAuthService> logger)
    {
        _httpClientFactory = httpClientFactory;
        _cache = cache;
        _options = options.Value;
        _logger = logger;
    }

    public bool HasCredentials =>
        !string.IsNullOrWhiteSpace(_options.ClientId) &&
        !string.IsNullOrWhiteSpace(_options.ClientSecret);

    public string ApiBaseUrl => _options.UseSandbox
        ? "https://api.sandbox.ebay.com"
        : "https://api.ebay.com";

    public async Task<string?> GetAccessTokenAsync(CancellationToken cancellationToken)
    {
        if (!HasCredentials)
        {
            return null;
        }

        if (_cache.TryGetValue(CacheKey, out string? cached) && !string.IsNullOrWhiteSpace(cached))
        {
            return cached;
        }

        await _gate.WaitAsync(cancellationToken);
        try
        {
            if (_cache.TryGetValue(CacheKey, out cached) && !string.IsNullOrWhiteSpace(cached))
            {
                return cached;
            }

            var client = _httpClientFactory.CreateClient("ebay");
            using var request = new HttpRequestMessage(HttpMethod.Post, $"{ApiBaseUrl}/identity/v1/oauth2/token");
            var basic = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_options.ClientId}:{_options.ClientSecret}"));
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", basic);
            request.Content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"] = "client_credentials",
                ["scope"] = "https://api.ebay.com/oauth/api_scope"
            });

            using var response = await client.SendAsync(request, cancellationToken);
            var body = await response.Content.ReadAsStringAsync(cancellationToken);
            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning("eBay token request failed ({Status}): {Body}", response.StatusCode, body);
                return null;
            }

            using var json = JsonDocument.Parse(body);
            var token = json.RootElement.GetProperty("access_token").GetString();
            var expiresIn = json.RootElement.GetProperty("expires_in").GetInt32();

            if (string.IsNullOrWhiteSpace(token))
            {
                return null;
            }

            // eBay tokens last about 2 hours. Refresh a bit early.
            _cache.Set(CacheKey, token, TimeSpan.FromSeconds(Math.Max(expiresIn - 300, 60)));
            return token;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not get an eBay access token.");
            return null;
        }
        finally
        {
            _gate.Release();
        }
    }
}
